gdjs.GameplayCode = {};
gdjs.GameplayCode.GDFood1Objects1= [];
gdjs.GameplayCode.GDFood1Objects2= [];
gdjs.GameplayCode.GDFood1Objects3= [];
gdjs.GameplayCode.GDFood1_951Objects1= [];
gdjs.GameplayCode.GDFood1_951Objects2= [];
gdjs.GameplayCode.GDFood1_951Objects3= [];
gdjs.GameplayCode.GDFood1_952Objects1= [];
gdjs.GameplayCode.GDFood1_952Objects2= [];
gdjs.GameplayCode.GDFood1_952Objects3= [];
gdjs.GameplayCode.GDFood1_953Objects1= [];
gdjs.GameplayCode.GDFood1_953Objects2= [];
gdjs.GameplayCode.GDFood1_953Objects3= [];
gdjs.GameplayCode.GDFood1_954Objects1= [];
gdjs.GameplayCode.GDFood1_954Objects2= [];
gdjs.GameplayCode.GDFood1_954Objects3= [];
gdjs.GameplayCode.GDFood2Objects1= [];
gdjs.GameplayCode.GDFood2Objects2= [];
gdjs.GameplayCode.GDFood2Objects3= [];
gdjs.GameplayCode.GDFood2_951Objects1= [];
gdjs.GameplayCode.GDFood2_951Objects2= [];
gdjs.GameplayCode.GDFood2_951Objects3= [];
gdjs.GameplayCode.GDFood2_952Objects1= [];
gdjs.GameplayCode.GDFood2_952Objects2= [];
gdjs.GameplayCode.GDFood2_952Objects3= [];
gdjs.GameplayCode.GDFood2_953Objects1= [];
gdjs.GameplayCode.GDFood2_953Objects2= [];
gdjs.GameplayCode.GDFood2_953Objects3= [];
gdjs.GameplayCode.GDFood2_954Objects1= [];
gdjs.GameplayCode.GDFood2_954Objects2= [];
gdjs.GameplayCode.GDFood2_954Objects3= [];
gdjs.GameplayCode.GDFood3Objects1= [];
gdjs.GameplayCode.GDFood3Objects2= [];
gdjs.GameplayCode.GDFood3Objects3= [];
gdjs.GameplayCode.GDFood3_951Objects1= [];
gdjs.GameplayCode.GDFood3_951Objects2= [];
gdjs.GameplayCode.GDFood3_951Objects3= [];
gdjs.GameplayCode.GDFood3_952Objects1= [];
gdjs.GameplayCode.GDFood3_952Objects2= [];
gdjs.GameplayCode.GDFood3_952Objects3= [];
gdjs.GameplayCode.GDFood3_953Objects1= [];
gdjs.GameplayCode.GDFood3_953Objects2= [];
gdjs.GameplayCode.GDFood3_953Objects3= [];
gdjs.GameplayCode.GDFood3_954Objects1= [];
gdjs.GameplayCode.GDFood3_954Objects2= [];
gdjs.GameplayCode.GDFood3_954Objects3= [];
gdjs.GameplayCode.GDFood4Objects1= [];
gdjs.GameplayCode.GDFood4Objects2= [];
gdjs.GameplayCode.GDFood4Objects3= [];
gdjs.GameplayCode.GDFood4_951Objects1= [];
gdjs.GameplayCode.GDFood4_951Objects2= [];
gdjs.GameplayCode.GDFood4_951Objects3= [];
gdjs.GameplayCode.GDFood4_952Objects1= [];
gdjs.GameplayCode.GDFood4_952Objects2= [];
gdjs.GameplayCode.GDFood4_952Objects3= [];
gdjs.GameplayCode.GDFood4_953Objects1= [];
gdjs.GameplayCode.GDFood4_953Objects2= [];
gdjs.GameplayCode.GDFood4_953Objects3= [];
gdjs.GameplayCode.GDFood4_954Objects1= [];
gdjs.GameplayCode.GDFood4_954Objects2= [];
gdjs.GameplayCode.GDFood4_954Objects3= [];
gdjs.GameplayCode.GDPizzaObjects1= [];
gdjs.GameplayCode.GDPizzaObjects2= [];
gdjs.GameplayCode.GDPizzaObjects3= [];
gdjs.GameplayCode.GDKnifeObjects1= [];
gdjs.GameplayCode.GDKnifeObjects2= [];
gdjs.GameplayCode.GDKnifeObjects3= [];
gdjs.GameplayCode.GDMasherObjects1= [];
gdjs.GameplayCode.GDMasherObjects2= [];
gdjs.GameplayCode.GDMasherObjects3= [];
gdjs.GameplayCode.GDPeelerObjects1= [];
gdjs.GameplayCode.GDPeelerObjects2= [];
gdjs.GameplayCode.GDPeelerObjects3= [];
gdjs.GameplayCode.GDScoreObjects1= [];
gdjs.GameplayCode.GDScoreObjects2= [];
gdjs.GameplayCode.GDScoreObjects3= [];
gdjs.GameplayCode.GDOrderDisplayObjects1= [];
gdjs.GameplayCode.GDOrderDisplayObjects2= [];
gdjs.GameplayCode.GDOrderDisplayObjects3= [];
gdjs.GameplayCode.GDLifeObjects1= [];
gdjs.GameplayCode.GDLifeObjects2= [];
gdjs.GameplayCode.GDLifeObjects3= [];
gdjs.GameplayCode.GDNewObject2Objects1= [];
gdjs.GameplayCode.GDNewObject2Objects2= [];
gdjs.GameplayCode.GDNewObject2Objects3= [];
gdjs.GameplayCode.GDNewObjectObjects1= [];
gdjs.GameplayCode.GDNewObjectObjects2= [];
gdjs.GameplayCode.GDNewObjectObjects3= [];
gdjs.GameplayCode.GDProgressObjects1= [];
gdjs.GameplayCode.GDProgressObjects2= [];
gdjs.GameplayCode.GDProgressObjects3= [];
gdjs.GameplayCode.GDStatistics1Objects1= [];
gdjs.GameplayCode.GDStatistics1Objects2= [];
gdjs.GameplayCode.GDStatistics1Objects3= [];
gdjs.GameplayCode.GDVulnerabilityObjects1= [];
gdjs.GameplayCode.GDVulnerabilityObjects2= [];
gdjs.GameplayCode.GDVulnerabilityObjects3= [];
gdjs.GameplayCode.GDGameOverMenuObjects1= [];
gdjs.GameplayCode.GDGameOverMenuObjects2= [];
gdjs.GameplayCode.GDGameOverMenuObjects3= [];
gdjs.GameplayCode.GDGameOverTextObjects1= [];
gdjs.GameplayCode.GDGameOverTextObjects2= [];
gdjs.GameplayCode.GDGameOverTextObjects3= [];
gdjs.GameplayCode.GDGameOverScoreObjects1= [];
gdjs.GameplayCode.GDGameOverScoreObjects2= [];
gdjs.GameplayCode.GDGameOverScoreObjects3= [];
gdjs.GameplayCode.GDUsernameObjects1= [];
gdjs.GameplayCode.GDUsernameObjects2= [];
gdjs.GameplayCode.GDUsernameObjects3= [];
gdjs.GameplayCode.GDUsernameHintObjects1= [];
gdjs.GameplayCode.GDUsernameHintObjects2= [];
gdjs.GameplayCode.GDUsernameHintObjects3= [];
gdjs.GameplayCode.GDScoreSavedObjects1= [];
gdjs.GameplayCode.GDScoreSavedObjects2= [];
gdjs.GameplayCode.GDScoreSavedObjects3= [];
gdjs.GameplayCode.GDSaveScoreObjects1= [];
gdjs.GameplayCode.GDSaveScoreObjects2= [];
gdjs.GameplayCode.GDSaveScoreObjects3= [];
gdjs.GameplayCode.GDRestartButtonObjects1= [];
gdjs.GameplayCode.GDRestartButtonObjects2= [];
gdjs.GameplayCode.GDRestartButtonObjects3= [];
gdjs.GameplayCode.GDMenuButtonObjects1= [];
gdjs.GameplayCode.GDMenuButtonObjects2= [];
gdjs.GameplayCode.GDMenuButtonObjects3= [];
gdjs.GameplayCode.GDEscMenuTextObjects1= [];
gdjs.GameplayCode.GDEscMenuTextObjects2= [];
gdjs.GameplayCode.GDEscMenuTextObjects3= [];
gdjs.GameplayCode.GDContinueButtonObjects1= [];
gdjs.GameplayCode.GDContinueButtonObjects2= [];
gdjs.GameplayCode.GDContinueButtonObjects3= [];
gdjs.GameplayCode.GDEscMenuObjects1= [];
gdjs.GameplayCode.GDEscMenuObjects2= [];
gdjs.GameplayCode.GDEscMenuObjects3= [];
gdjs.GameplayCode.GDFood8_954Objects1= [];
gdjs.GameplayCode.GDFood8_954Objects2= [];
gdjs.GameplayCode.GDFood8_954Objects3= [];
gdjs.GameplayCode.GDFood8_953Objects1= [];
gdjs.GameplayCode.GDFood8_953Objects2= [];
gdjs.GameplayCode.GDFood8_953Objects3= [];
gdjs.GameplayCode.GDFood8_952Objects1= [];
gdjs.GameplayCode.GDFood8_952Objects2= [];
gdjs.GameplayCode.GDFood8_952Objects3= [];
gdjs.GameplayCode.GDFood8_951Objects1= [];
gdjs.GameplayCode.GDFood8_951Objects2= [];
gdjs.GameplayCode.GDFood8_951Objects3= [];
gdjs.GameplayCode.GDFood8Objects1= [];
gdjs.GameplayCode.GDFood8Objects2= [];
gdjs.GameplayCode.GDFood8Objects3= [];
gdjs.GameplayCode.GDFood7_954Objects1= [];
gdjs.GameplayCode.GDFood7_954Objects2= [];
gdjs.GameplayCode.GDFood7_954Objects3= [];
gdjs.GameplayCode.GDFood7_953Objects1= [];
gdjs.GameplayCode.GDFood7_953Objects2= [];
gdjs.GameplayCode.GDFood7_953Objects3= [];
gdjs.GameplayCode.GDFood7_952Objects1= [];
gdjs.GameplayCode.GDFood7_952Objects2= [];
gdjs.GameplayCode.GDFood7_952Objects3= [];
gdjs.GameplayCode.GDFood7_951Objects1= [];
gdjs.GameplayCode.GDFood7_951Objects2= [];
gdjs.GameplayCode.GDFood7_951Objects3= [];
gdjs.GameplayCode.GDFood7Objects1= [];
gdjs.GameplayCode.GDFood7Objects2= [];
gdjs.GameplayCode.GDFood7Objects3= [];
gdjs.GameplayCode.GDFood6_954Objects1= [];
gdjs.GameplayCode.GDFood6_954Objects2= [];
gdjs.GameplayCode.GDFood6_954Objects3= [];
gdjs.GameplayCode.GDFood6_953Objects1= [];
gdjs.GameplayCode.GDFood6_953Objects2= [];
gdjs.GameplayCode.GDFood6_953Objects3= [];
gdjs.GameplayCode.GDFood6_952Objects1= [];
gdjs.GameplayCode.GDFood6_952Objects2= [];
gdjs.GameplayCode.GDFood6_952Objects3= [];
gdjs.GameplayCode.GDFood6_951Objects1= [];
gdjs.GameplayCode.GDFood6_951Objects2= [];
gdjs.GameplayCode.GDFood6_951Objects3= [];
gdjs.GameplayCode.GDFood6Objects1= [];
gdjs.GameplayCode.GDFood6Objects2= [];
gdjs.GameplayCode.GDFood6Objects3= [];
gdjs.GameplayCode.GDFood5_954Objects1= [];
gdjs.GameplayCode.GDFood5_954Objects2= [];
gdjs.GameplayCode.GDFood5_954Objects3= [];
gdjs.GameplayCode.GDFood5_953Objects1= [];
gdjs.GameplayCode.GDFood5_953Objects2= [];
gdjs.GameplayCode.GDFood5_953Objects3= [];
gdjs.GameplayCode.GDFood5_952Objects1= [];
gdjs.GameplayCode.GDFood5_952Objects2= [];
gdjs.GameplayCode.GDFood5_952Objects3= [];
gdjs.GameplayCode.GDFood5_951Objects1= [];
gdjs.GameplayCode.GDFood5_951Objects2= [];
gdjs.GameplayCode.GDFood5_951Objects3= [];
gdjs.GameplayCode.GDFood5Objects1= [];
gdjs.GameplayCode.GDFood5Objects2= [];
gdjs.GameplayCode.GDFood5Objects3= [];

gdjs.GameplayCode.conditionTrue_0 = {val:false};
gdjs.GameplayCode.condition0IsTrue_0 = {val:false};
gdjs.GameplayCode.condition1IsTrue_0 = {val:false};
gdjs.GameplayCode.condition2IsTrue_0 = {val:false};
gdjs.GameplayCode.condition3IsTrue_0 = {val:false};
gdjs.GameplayCode.conditionTrue_1 = {val:false};
gdjs.GameplayCode.condition0IsTrue_1 = {val:false};
gdjs.GameplayCode.condition1IsTrue_1 = {val:false};
gdjs.GameplayCode.condition2IsTrue_1 = {val:false};
gdjs.GameplayCode.condition3IsTrue_1 = {val:false};


gdjs.GameplayCode.eventsList0 = function(runtimeScene) {

};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8Objects1Objects = Hashtable.newFrom({"Food1": gdjs.GameplayCode.GDFood1Objects1, "Food2": gdjs.GameplayCode.GDFood2Objects1, "Food3": gdjs.GameplayCode.GDFood3Objects1, "Food4": gdjs.GameplayCode.GDFood4Objects1, "Food5": gdjs.GameplayCode.GDFood5Objects1, "Food6": gdjs.GameplayCode.GDFood6Objects1, "Food7": gdjs.GameplayCode.GDFood7Objects1, "Food8": gdjs.GameplayCode.GDFood8Objects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8Objects1Objects = Hashtable.newFrom({"Food1": gdjs.GameplayCode.GDFood1Objects1, "Food2": gdjs.GameplayCode.GDFood2Objects1, "Food3": gdjs.GameplayCode.GDFood3Objects1, "Food4": gdjs.GameplayCode.GDFood4Objects1, "Food5": gdjs.GameplayCode.GDFood5Objects1, "Food6": gdjs.GameplayCode.GDFood6Objects1, "Food7": gdjs.GameplayCode.GDFood7Objects1, "Food8": gdjs.GameplayCode.GDFood8Objects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95954Objects1Objects = Hashtable.newFrom({"Food1_1": gdjs.GameplayCode.GDFood1_951Objects1, "Food1_2": gdjs.GameplayCode.GDFood1_952Objects1, "Food2_2": gdjs.GameplayCode.GDFood2_952Objects1, "Food3_1": gdjs.GameplayCode.GDFood3_951Objects1, "Food3_2": gdjs.GameplayCode.GDFood3_952Objects1, "Food4_1": gdjs.GameplayCode.GDFood4_951Objects1, "Food4_2": gdjs.GameplayCode.GDFood4_952Objects1, "Food2_1": gdjs.GameplayCode.GDFood2_951Objects1, "Food1_3": gdjs.GameplayCode.GDFood1_953Objects1, "Food2_3": gdjs.GameplayCode.GDFood2_953Objects1, "Food3_3": gdjs.GameplayCode.GDFood3_953Objects1, "Food4_3": gdjs.GameplayCode.GDFood4_953Objects1, "Food1_4": gdjs.GameplayCode.GDFood1_954Objects1, "Food2_4": gdjs.GameplayCode.GDFood2_954Objects1, "Food3_4": gdjs.GameplayCode.GDFood3_954Objects1, "Food4_4": gdjs.GameplayCode.GDFood4_954Objects1, "Food5_1": gdjs.GameplayCode.GDFood5_951Objects1, "Food5_2": gdjs.GameplayCode.GDFood5_952Objects1, "Food5_3": gdjs.GameplayCode.GDFood5_953Objects1, "Food5_4": gdjs.GameplayCode.GDFood5_954Objects1, "Food6_1": gdjs.GameplayCode.GDFood6_951Objects1, "Food6_2": gdjs.GameplayCode.GDFood6_952Objects1, "Food6_3": gdjs.GameplayCode.GDFood6_953Objects1, "Food6_4": gdjs.GameplayCode.GDFood6_954Objects1, "Food7_1": gdjs.GameplayCode.GDFood7_951Objects1, "Food7_2": gdjs.GameplayCode.GDFood7_952Objects1, "Food7_3": gdjs.GameplayCode.GDFood7_953Objects1, "Food7_4": gdjs.GameplayCode.GDFood7_954Objects1, "Food8_1": gdjs.GameplayCode.GDFood8_951Objects1, "Food8_2": gdjs.GameplayCode.GDFood8_952Objects1, "Food8_3": gdjs.GameplayCode.GDFood8_953Objects1, "Food8_4": gdjs.GameplayCode.GDFood8_954Objects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDProgressObjects1Objects = Hashtable.newFrom({"Progress": gdjs.GameplayCode.GDProgressObjects1});gdjs.GameplayCode.eventsList1 = function(runtimeScene) {

};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDKnifeObjects1Objects = Hashtable.newFrom({"Knife": gdjs.GameplayCode.GDKnifeObjects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8Objects1Objects = Hashtable.newFrom({"Food1": gdjs.GameplayCode.GDFood1Objects1, "Food2": gdjs.GameplayCode.GDFood2Objects1, "Food3": gdjs.GameplayCode.GDFood3Objects1, "Food4": gdjs.GameplayCode.GDFood4Objects1, "Food5": gdjs.GameplayCode.GDFood5Objects1, "Food6": gdjs.GameplayCode.GDFood6Objects1, "Food7": gdjs.GameplayCode.GDFood7Objects1, "Food8": gdjs.GameplayCode.GDFood8Objects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8Objects1Objects = Hashtable.newFrom({"Food1": gdjs.GameplayCode.GDFood1Objects1, "Food2": gdjs.GameplayCode.GDFood2Objects1, "Food3": gdjs.GameplayCode.GDFood3Objects1, "Food4": gdjs.GameplayCode.GDFood4Objects1, "Food5": gdjs.GameplayCode.GDFood5Objects1, "Food6": gdjs.GameplayCode.GDFood6Objects1, "Food7": gdjs.GameplayCode.GDFood7Objects1, "Food8": gdjs.GameplayCode.GDFood8Objects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDLifeObjects2Objects = Hashtable.newFrom({"Life": gdjs.GameplayCode.GDLifeObjects2});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95954Objects1Objects = Hashtable.newFrom({"Food1_1": gdjs.GameplayCode.GDFood1_951Objects1, "Food1_2": gdjs.GameplayCode.GDFood1_952Objects1, "Food2_2": gdjs.GameplayCode.GDFood2_952Objects1, "Food3_1": gdjs.GameplayCode.GDFood3_951Objects1, "Food3_2": gdjs.GameplayCode.GDFood3_952Objects1, "Food4_1": gdjs.GameplayCode.GDFood4_951Objects1, "Food4_2": gdjs.GameplayCode.GDFood4_952Objects1, "Food2_1": gdjs.GameplayCode.GDFood2_951Objects1, "Food1_3": gdjs.GameplayCode.GDFood1_953Objects1, "Food2_3": gdjs.GameplayCode.GDFood2_953Objects1, "Food3_3": gdjs.GameplayCode.GDFood3_953Objects1, "Food4_3": gdjs.GameplayCode.GDFood4_953Objects1, "Food1_4": gdjs.GameplayCode.GDFood1_954Objects1, "Food2_4": gdjs.GameplayCode.GDFood2_954Objects1, "Food3_4": gdjs.GameplayCode.GDFood3_954Objects1, "Food4_4": gdjs.GameplayCode.GDFood4_954Objects1, "Food5_1": gdjs.GameplayCode.GDFood5_951Objects1, "Food5_2": gdjs.GameplayCode.GDFood5_952Objects1, "Food5_3": gdjs.GameplayCode.GDFood5_953Objects1, "Food5_4": gdjs.GameplayCode.GDFood5_954Objects1, "Food6_1": gdjs.GameplayCode.GDFood6_951Objects1, "Food6_2": gdjs.GameplayCode.GDFood6_952Objects1, "Food6_3": gdjs.GameplayCode.GDFood6_953Objects1, "Food6_4": gdjs.GameplayCode.GDFood6_954Objects1, "Food7_1": gdjs.GameplayCode.GDFood7_951Objects1, "Food7_2": gdjs.GameplayCode.GDFood7_952Objects1, "Food7_3": gdjs.GameplayCode.GDFood7_953Objects1, "Food7_4": gdjs.GameplayCode.GDFood7_954Objects1, "Food8_1": gdjs.GameplayCode.GDFood8_951Objects1, "Food8_2": gdjs.GameplayCode.GDFood8_952Objects1, "Food8_3": gdjs.GameplayCode.GDFood8_953Objects1, "Food8_4": gdjs.GameplayCode.GDFood8_954Objects1});gdjs.GameplayCode.eventsList2 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 1;
if( gdjs.GameplayCode.condition0IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
}
}
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 3;
if( gdjs.GameplayCode.condition1IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
}
}
{
gdjs.GameplayCode.condition2IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 4;
if( gdjs.GameplayCode.condition2IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
}
}
{
}
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9980820);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.GameplayCode.GDFood1Objects1, gdjs.GameplayCode.GDFood1Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food1_1"), gdjs.GameplayCode.GDFood1_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food1_2"), gdjs.GameplayCode.GDFood1_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food1_3"), gdjs.GameplayCode.GDFood1_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food1_4"), gdjs.GameplayCode.GDFood1_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood2Objects1, gdjs.GameplayCode.GDFood2Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food2_1"), gdjs.GameplayCode.GDFood2_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food2_2"), gdjs.GameplayCode.GDFood2_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food2_3"), gdjs.GameplayCode.GDFood2_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food2_4"), gdjs.GameplayCode.GDFood2_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood3Objects1, gdjs.GameplayCode.GDFood3Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food3_1"), gdjs.GameplayCode.GDFood3_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food3_2"), gdjs.GameplayCode.GDFood3_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food3_3"), gdjs.GameplayCode.GDFood3_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food3_4"), gdjs.GameplayCode.GDFood3_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood4Objects1, gdjs.GameplayCode.GDFood4Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food4_1"), gdjs.GameplayCode.GDFood4_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food4_2"), gdjs.GameplayCode.GDFood4_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food4_3"), gdjs.GameplayCode.GDFood4_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food4_4"), gdjs.GameplayCode.GDFood4_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood5Objects1, gdjs.GameplayCode.GDFood5Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food5_1"), gdjs.GameplayCode.GDFood5_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food5_2"), gdjs.GameplayCode.GDFood5_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food5_3"), gdjs.GameplayCode.GDFood5_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food5_4"), gdjs.GameplayCode.GDFood5_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood6Objects1, gdjs.GameplayCode.GDFood6Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food6_1"), gdjs.GameplayCode.GDFood6_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food6_2"), gdjs.GameplayCode.GDFood6_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food6_3"), gdjs.GameplayCode.GDFood6_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food6_4"), gdjs.GameplayCode.GDFood6_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood7Objects1, gdjs.GameplayCode.GDFood7Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food7_1"), gdjs.GameplayCode.GDFood7_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food7_2"), gdjs.GameplayCode.GDFood7_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food7_3"), gdjs.GameplayCode.GDFood7_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food7_4"), gdjs.GameplayCode.GDFood7_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood8Objects1, gdjs.GameplayCode.GDFood8Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food8_1"), gdjs.GameplayCode.GDFood8_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food8_2"), gdjs.GameplayCode.GDFood8_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food8_3"), gdjs.GameplayCode.GDFood8_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food8_4"), gdjs.GameplayCode.GDFood8_954Objects2);
gdjs.GameplayCode.GDLifeObjects2.length = 0;

{for(var i = 0, len = gdjs.GameplayCode.GDFood1Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFood1_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_954Objects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDLifeObjects2Objects, 600 + (gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) * 60), 62, "");
}{for(var i = 0, len = gdjs.GameplayCode.GDLifeObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDLifeObjects2[i].setScale(0.5);
}
}{runtimeScene.getVariables().getFromIndex(3).add(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "FailureWarning");
}{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "255;96;96");
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 2;
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9982908);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDFood1Objects1 */
/* Reuse gdjs.GameplayCode.GDFood2Objects1 */
/* Reuse gdjs.GameplayCode.GDFood3Objects1 */
/* Reuse gdjs.GameplayCode.GDFood4Objects1 */
/* Reuse gdjs.GameplayCode.GDFood5Objects1 */
/* Reuse gdjs.GameplayCode.GDFood6Objects1 */
/* Reuse gdjs.GameplayCode.GDFood7Objects1 */
/* Reuse gdjs.GameplayCode.GDFood8Objects1 */
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.GameplayCode.GDScoreObjects1);
gdjs.GameplayCode.GDFood1_951Objects1.length = 0;

gdjs.GameplayCode.GDFood1_952Objects1.length = 0;

gdjs.GameplayCode.GDFood1_953Objects1.length = 0;

gdjs.GameplayCode.GDFood1_954Objects1.length = 0;

gdjs.GameplayCode.GDFood2_951Objects1.length = 0;

gdjs.GameplayCode.GDFood2_952Objects1.length = 0;

gdjs.GameplayCode.GDFood2_953Objects1.length = 0;

gdjs.GameplayCode.GDFood2_954Objects1.length = 0;

gdjs.GameplayCode.GDFood3_951Objects1.length = 0;

gdjs.GameplayCode.GDFood3_952Objects1.length = 0;

gdjs.GameplayCode.GDFood3_953Objects1.length = 0;

gdjs.GameplayCode.GDFood3_954Objects1.length = 0;

gdjs.GameplayCode.GDFood4_951Objects1.length = 0;

gdjs.GameplayCode.GDFood4_952Objects1.length = 0;

gdjs.GameplayCode.GDFood4_953Objects1.length = 0;

gdjs.GameplayCode.GDFood4_954Objects1.length = 0;

gdjs.GameplayCode.GDFood5_951Objects1.length = 0;

gdjs.GameplayCode.GDFood5_952Objects1.length = 0;

gdjs.GameplayCode.GDFood5_953Objects1.length = 0;

gdjs.GameplayCode.GDFood5_954Objects1.length = 0;

gdjs.GameplayCode.GDFood6_951Objects1.length = 0;

gdjs.GameplayCode.GDFood6_952Objects1.length = 0;

gdjs.GameplayCode.GDFood6_953Objects1.length = 0;

gdjs.GameplayCode.GDFood6_954Objects1.length = 0;

gdjs.GameplayCode.GDFood7_951Objects1.length = 0;

gdjs.GameplayCode.GDFood7_952Objects1.length = 0;

gdjs.GameplayCode.GDFood7_953Objects1.length = 0;

gdjs.GameplayCode.GDFood7_954Objects1.length = 0;

gdjs.GameplayCode.GDFood8_951Objects1.length = 0;

gdjs.GameplayCode.GDFood8_952Objects1.length = 0;

gdjs.GameplayCode.GDFood8_953Objects1.length = 0;

gdjs.GameplayCode.GDFood8_954Objects1.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95954Objects1Objects, "Food" + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) + "_" + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)), (( gdjs.GameplayCode.GDFood8Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood7Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood6Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood5Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood4Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood3Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood2Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood1Objects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDFood1Objects1[0].getPointX("")) :gdjs.GameplayCode.GDFood2Objects1[0].getPointX("")) :gdjs.GameplayCode.GDFood3Objects1[0].getPointX("")) :gdjs.GameplayCode.GDFood4Objects1[0].getPointX("")) :gdjs.GameplayCode.GDFood5Objects1[0].getPointX("")) :gdjs.GameplayCode.GDFood6Objects1[0].getPointX("")) :gdjs.GameplayCode.GDFood7Objects1[0].getPointX("")) :gdjs.GameplayCode.GDFood8Objects1[0].getPointX("")), (( gdjs.GameplayCode.GDFood8Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood7Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood6Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood5Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood4Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood3Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood2Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood1Objects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDFood1Objects1[0].getPointY("")) :gdjs.GameplayCode.GDFood2Objects1[0].getPointY("")) :gdjs.GameplayCode.GDFood3Objects1[0].getPointY("")) :gdjs.GameplayCode.GDFood4Objects1[0].getPointY("")) :gdjs.GameplayCode.GDFood5Objects1[0].getPointY("")) :gdjs.GameplayCode.GDFood6Objects1[0].getPointY("")) :gdjs.GameplayCode.GDFood7Objects1[0].getPointY("")) :gdjs.GameplayCode.GDFood8Objects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.GameplayCode.GDFood1_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_954Objects1[i].setScale(1.5);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFood1Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8Objects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "FoodPrepared");
}{runtimeScene.getVariables().getFromIndex(2).add(1);
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1 + gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) * 0.075);
}{for(var i = 0, len = gdjs.GameplayCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)));
}
}}

}


};gdjs.GameplayCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Food1"), gdjs.GameplayCode.GDFood1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food2"), gdjs.GameplayCode.GDFood2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food3"), gdjs.GameplayCode.GDFood3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food4"), gdjs.GameplayCode.GDFood4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food5"), gdjs.GameplayCode.GDFood5Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food6"), gdjs.GameplayCode.GDFood6Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food7"), gdjs.GameplayCode.GDFood7Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food8"), gdjs.GameplayCode.GDFood8Objects1);
gdjs.copyArray(runtimeScene.getObjects("Knife"), gdjs.GameplayCode.GDKnifeObjects1);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDKnifeObjects1Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8Objects1Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8Objects1Objects) > 0;
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition2IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9978820);
}
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "OrderTimeLimit");
}
{ //Subevents
gdjs.GameplayCode.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDMasherObjects1Objects = Hashtable.newFrom({"Masher": gdjs.GameplayCode.GDMasherObjects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8Objects1Objects = Hashtable.newFrom({"Food1": gdjs.GameplayCode.GDFood1Objects1, "Food2": gdjs.GameplayCode.GDFood2Objects1, "Food3": gdjs.GameplayCode.GDFood3Objects1, "Food4": gdjs.GameplayCode.GDFood4Objects1, "Food5": gdjs.GameplayCode.GDFood5Objects1, "Food6": gdjs.GameplayCode.GDFood6Objects1, "Food7": gdjs.GameplayCode.GDFood7Objects1, "Food8": gdjs.GameplayCode.GDFood8Objects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8Objects1Objects = Hashtable.newFrom({"Food1": gdjs.GameplayCode.GDFood1Objects1, "Food2": gdjs.GameplayCode.GDFood2Objects1, "Food3": gdjs.GameplayCode.GDFood3Objects1, "Food4": gdjs.GameplayCode.GDFood4Objects1, "Food5": gdjs.GameplayCode.GDFood5Objects1, "Food6": gdjs.GameplayCode.GDFood6Objects1, "Food7": gdjs.GameplayCode.GDFood7Objects1, "Food8": gdjs.GameplayCode.GDFood8Objects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDLifeObjects2Objects = Hashtable.newFrom({"Life": gdjs.GameplayCode.GDLifeObjects2});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95954Objects1Objects = Hashtable.newFrom({"Food1_1": gdjs.GameplayCode.GDFood1_951Objects1, "Food1_2": gdjs.GameplayCode.GDFood1_952Objects1, "Food2_2": gdjs.GameplayCode.GDFood2_952Objects1, "Food3_1": gdjs.GameplayCode.GDFood3_951Objects1, "Food3_2": gdjs.GameplayCode.GDFood3_952Objects1, "Food4_1": gdjs.GameplayCode.GDFood4_951Objects1, "Food4_2": gdjs.GameplayCode.GDFood4_952Objects1, "Food2_1": gdjs.GameplayCode.GDFood2_951Objects1, "Food1_3": gdjs.GameplayCode.GDFood1_953Objects1, "Food2_3": gdjs.GameplayCode.GDFood2_953Objects1, "Food3_3": gdjs.GameplayCode.GDFood3_953Objects1, "Food4_3": gdjs.GameplayCode.GDFood4_953Objects1, "Food1_4": gdjs.GameplayCode.GDFood1_954Objects1, "Food2_4": gdjs.GameplayCode.GDFood2_954Objects1, "Food3_4": gdjs.GameplayCode.GDFood3_954Objects1, "Food4_4": gdjs.GameplayCode.GDFood4_954Objects1, "Food5_1": gdjs.GameplayCode.GDFood5_951Objects1, "Food5_2": gdjs.GameplayCode.GDFood5_952Objects1, "Food5_3": gdjs.GameplayCode.GDFood5_953Objects1, "Food5_4": gdjs.GameplayCode.GDFood5_954Objects1, "Food6_1": gdjs.GameplayCode.GDFood6_951Objects1, "Food6_2": gdjs.GameplayCode.GDFood6_952Objects1, "Food6_3": gdjs.GameplayCode.GDFood6_953Objects1, "Food6_4": gdjs.GameplayCode.GDFood6_954Objects1, "Food7_1": gdjs.GameplayCode.GDFood7_951Objects1, "Food7_2": gdjs.GameplayCode.GDFood7_952Objects1, "Food7_3": gdjs.GameplayCode.GDFood7_953Objects1, "Food7_4": gdjs.GameplayCode.GDFood7_954Objects1, "Food8_1": gdjs.GameplayCode.GDFood8_951Objects1, "Food8_2": gdjs.GameplayCode.GDFood8_952Objects1, "Food8_3": gdjs.GameplayCode.GDFood8_953Objects1, "Food8_4": gdjs.GameplayCode.GDFood8_954Objects1});gdjs.GameplayCode.eventsList4 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 1;
if( gdjs.GameplayCode.condition0IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
}
}
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 2;
if( gdjs.GameplayCode.condition1IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
}
}
{
gdjs.GameplayCode.condition2IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 4;
if( gdjs.GameplayCode.condition2IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
}
}
{
}
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9987404);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.GameplayCode.GDFood1Objects1, gdjs.GameplayCode.GDFood1Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food1_1"), gdjs.GameplayCode.GDFood1_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food1_2"), gdjs.GameplayCode.GDFood1_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food1_3"), gdjs.GameplayCode.GDFood1_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food1_4"), gdjs.GameplayCode.GDFood1_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood2Objects1, gdjs.GameplayCode.GDFood2Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food2_1"), gdjs.GameplayCode.GDFood2_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food2_2"), gdjs.GameplayCode.GDFood2_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food2_3"), gdjs.GameplayCode.GDFood2_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food2_4"), gdjs.GameplayCode.GDFood2_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood3Objects1, gdjs.GameplayCode.GDFood3Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food3_1"), gdjs.GameplayCode.GDFood3_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food3_2"), gdjs.GameplayCode.GDFood3_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food3_3"), gdjs.GameplayCode.GDFood3_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food3_4"), gdjs.GameplayCode.GDFood3_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood4Objects1, gdjs.GameplayCode.GDFood4Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food4_1"), gdjs.GameplayCode.GDFood4_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food4_2"), gdjs.GameplayCode.GDFood4_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food4_3"), gdjs.GameplayCode.GDFood4_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food4_4"), gdjs.GameplayCode.GDFood4_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood5Objects1, gdjs.GameplayCode.GDFood5Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food5_1"), gdjs.GameplayCode.GDFood5_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food5_2"), gdjs.GameplayCode.GDFood5_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food5_3"), gdjs.GameplayCode.GDFood5_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food5_4"), gdjs.GameplayCode.GDFood5_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood6Objects1, gdjs.GameplayCode.GDFood6Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food6_1"), gdjs.GameplayCode.GDFood6_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food6_2"), gdjs.GameplayCode.GDFood6_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food6_3"), gdjs.GameplayCode.GDFood6_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food6_4"), gdjs.GameplayCode.GDFood6_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood7Objects1, gdjs.GameplayCode.GDFood7Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food7_1"), gdjs.GameplayCode.GDFood7_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food7_2"), gdjs.GameplayCode.GDFood7_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food7_3"), gdjs.GameplayCode.GDFood7_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food7_4"), gdjs.GameplayCode.GDFood7_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood8Objects1, gdjs.GameplayCode.GDFood8Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food8_1"), gdjs.GameplayCode.GDFood8_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food8_2"), gdjs.GameplayCode.GDFood8_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food8_3"), gdjs.GameplayCode.GDFood8_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food8_4"), gdjs.GameplayCode.GDFood8_954Objects2);
gdjs.GameplayCode.GDLifeObjects2.length = 0;

{for(var i = 0, len = gdjs.GameplayCode.GDFood1Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFood1_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_954Objects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDLifeObjects2Objects, 600 + (gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) * 60), 62, "");
}{for(var i = 0, len = gdjs.GameplayCode.GDLifeObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDLifeObjects2[i].setScale(0.5);
}
}{runtimeScene.getVariables().getFromIndex(3).add(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "FailureWarning");
}{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "255;96;96");
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 3;
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9989492);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDFood1Objects1 */
/* Reuse gdjs.GameplayCode.GDFood2Objects1 */
/* Reuse gdjs.GameplayCode.GDFood3Objects1 */
/* Reuse gdjs.GameplayCode.GDFood4Objects1 */
/* Reuse gdjs.GameplayCode.GDFood5Objects1 */
/* Reuse gdjs.GameplayCode.GDFood6Objects1 */
/* Reuse gdjs.GameplayCode.GDFood7Objects1 */
/* Reuse gdjs.GameplayCode.GDFood8Objects1 */
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.GameplayCode.GDScoreObjects1);
gdjs.GameplayCode.GDFood1_951Objects1.length = 0;

gdjs.GameplayCode.GDFood1_952Objects1.length = 0;

gdjs.GameplayCode.GDFood1_953Objects1.length = 0;

gdjs.GameplayCode.GDFood1_954Objects1.length = 0;

gdjs.GameplayCode.GDFood2_951Objects1.length = 0;

gdjs.GameplayCode.GDFood2_952Objects1.length = 0;

gdjs.GameplayCode.GDFood2_953Objects1.length = 0;

gdjs.GameplayCode.GDFood2_954Objects1.length = 0;

gdjs.GameplayCode.GDFood3_951Objects1.length = 0;

gdjs.GameplayCode.GDFood3_952Objects1.length = 0;

gdjs.GameplayCode.GDFood3_953Objects1.length = 0;

gdjs.GameplayCode.GDFood3_954Objects1.length = 0;

gdjs.GameplayCode.GDFood4_951Objects1.length = 0;

gdjs.GameplayCode.GDFood4_952Objects1.length = 0;

gdjs.GameplayCode.GDFood4_953Objects1.length = 0;

gdjs.GameplayCode.GDFood4_954Objects1.length = 0;

gdjs.GameplayCode.GDFood5_951Objects1.length = 0;

gdjs.GameplayCode.GDFood5_952Objects1.length = 0;

gdjs.GameplayCode.GDFood5_953Objects1.length = 0;

gdjs.GameplayCode.GDFood5_954Objects1.length = 0;

gdjs.GameplayCode.GDFood6_951Objects1.length = 0;

gdjs.GameplayCode.GDFood6_952Objects1.length = 0;

gdjs.GameplayCode.GDFood6_953Objects1.length = 0;

gdjs.GameplayCode.GDFood6_954Objects1.length = 0;

gdjs.GameplayCode.GDFood7_951Objects1.length = 0;

gdjs.GameplayCode.GDFood7_952Objects1.length = 0;

gdjs.GameplayCode.GDFood7_953Objects1.length = 0;

gdjs.GameplayCode.GDFood7_954Objects1.length = 0;

gdjs.GameplayCode.GDFood8_951Objects1.length = 0;

gdjs.GameplayCode.GDFood8_952Objects1.length = 0;

gdjs.GameplayCode.GDFood8_953Objects1.length = 0;

gdjs.GameplayCode.GDFood8_954Objects1.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95954Objects1Objects, "Food" + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) + "_" + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)), (( gdjs.GameplayCode.GDFood8Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood7Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood6Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood5Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood4Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood3Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood2Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood1Objects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDFood1Objects1[0].getPointX("")) :gdjs.GameplayCode.GDFood2Objects1[0].getPointX("")) :gdjs.GameplayCode.GDFood3Objects1[0].getPointX("")) :gdjs.GameplayCode.GDFood4Objects1[0].getPointX("")) :gdjs.GameplayCode.GDFood5Objects1[0].getPointX("")) :gdjs.GameplayCode.GDFood6Objects1[0].getPointX("")) :gdjs.GameplayCode.GDFood7Objects1[0].getPointX("")) :gdjs.GameplayCode.GDFood8Objects1[0].getPointX("")), (( gdjs.GameplayCode.GDFood8Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood7Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood6Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood5Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood4Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood3Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood2Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood1Objects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDFood1Objects1[0].getPointY("")) :gdjs.GameplayCode.GDFood2Objects1[0].getPointY("")) :gdjs.GameplayCode.GDFood3Objects1[0].getPointY("")) :gdjs.GameplayCode.GDFood4Objects1[0].getPointY("")) :gdjs.GameplayCode.GDFood5Objects1[0].getPointY("")) :gdjs.GameplayCode.GDFood6Objects1[0].getPointY("")) :gdjs.GameplayCode.GDFood7Objects1[0].getPointY("")) :gdjs.GameplayCode.GDFood8Objects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.GameplayCode.GDFood1_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_954Objects1[i].setScale(1.5);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFood1Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8Objects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "FoodPrepared");
}{runtimeScene.getVariables().getFromIndex(2).add(1);
}{for(var i = 0, len = gdjs.GameplayCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)));
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1 + gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) * 0.075);
}}

}


};gdjs.GameplayCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Food1"), gdjs.GameplayCode.GDFood1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food2"), gdjs.GameplayCode.GDFood2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food3"), gdjs.GameplayCode.GDFood3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food4"), gdjs.GameplayCode.GDFood4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food5"), gdjs.GameplayCode.GDFood5Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food6"), gdjs.GameplayCode.GDFood6Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food7"), gdjs.GameplayCode.GDFood7Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food8"), gdjs.GameplayCode.GDFood8Objects1);
gdjs.copyArray(runtimeScene.getObjects("Masher"), gdjs.GameplayCode.GDMasherObjects1);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDMasherObjects1Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8Objects1Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8Objects1Objects) > 0;
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition2IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9985604);
}
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "OrderTimeLimit");
}
{ //Subevents
gdjs.GameplayCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPeelerObjects1Objects = Hashtable.newFrom({"Peeler": gdjs.GameplayCode.GDPeelerObjects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8Objects1Objects = Hashtable.newFrom({"Food1": gdjs.GameplayCode.GDFood1Objects1, "Food2": gdjs.GameplayCode.GDFood2Objects1, "Food3": gdjs.GameplayCode.GDFood3Objects1, "Food4": gdjs.GameplayCode.GDFood4Objects1, "Food5": gdjs.GameplayCode.GDFood5Objects1, "Food6": gdjs.GameplayCode.GDFood6Objects1, "Food7": gdjs.GameplayCode.GDFood7Objects1, "Food8": gdjs.GameplayCode.GDFood8Objects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8Objects1Objects = Hashtable.newFrom({"Food1": gdjs.GameplayCode.GDFood1Objects1, "Food2": gdjs.GameplayCode.GDFood2Objects1, "Food3": gdjs.GameplayCode.GDFood3Objects1, "Food4": gdjs.GameplayCode.GDFood4Objects1, "Food5": gdjs.GameplayCode.GDFood5Objects1, "Food6": gdjs.GameplayCode.GDFood6Objects1, "Food7": gdjs.GameplayCode.GDFood7Objects1, "Food8": gdjs.GameplayCode.GDFood8Objects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDLifeObjects2Objects = Hashtable.newFrom({"Life": gdjs.GameplayCode.GDLifeObjects2});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95954Objects1Objects = Hashtable.newFrom({"Food1_1": gdjs.GameplayCode.GDFood1_951Objects1, "Food1_2": gdjs.GameplayCode.GDFood1_952Objects1, "Food2_2": gdjs.GameplayCode.GDFood2_952Objects1, "Food3_1": gdjs.GameplayCode.GDFood3_951Objects1, "Food3_2": gdjs.GameplayCode.GDFood3_952Objects1, "Food4_1": gdjs.GameplayCode.GDFood4_951Objects1, "Food4_2": gdjs.GameplayCode.GDFood4_952Objects1, "Food2_1": gdjs.GameplayCode.GDFood2_951Objects1, "Food1_3": gdjs.GameplayCode.GDFood1_953Objects1, "Food2_3": gdjs.GameplayCode.GDFood2_953Objects1, "Food3_3": gdjs.GameplayCode.GDFood3_953Objects1, "Food4_3": gdjs.GameplayCode.GDFood4_953Objects1, "Food1_4": gdjs.GameplayCode.GDFood1_954Objects1, "Food2_4": gdjs.GameplayCode.GDFood2_954Objects1, "Food3_4": gdjs.GameplayCode.GDFood3_954Objects1, "Food4_4": gdjs.GameplayCode.GDFood4_954Objects1, "Food5_1": gdjs.GameplayCode.GDFood5_951Objects1, "Food5_2": gdjs.GameplayCode.GDFood5_952Objects1, "Food5_3": gdjs.GameplayCode.GDFood5_953Objects1, "Food5_4": gdjs.GameplayCode.GDFood5_954Objects1, "Food6_1": gdjs.GameplayCode.GDFood6_951Objects1, "Food6_2": gdjs.GameplayCode.GDFood6_952Objects1, "Food6_3": gdjs.GameplayCode.GDFood6_953Objects1, "Food6_4": gdjs.GameplayCode.GDFood6_954Objects1, "Food7_1": gdjs.GameplayCode.GDFood7_951Objects1, "Food7_2": gdjs.GameplayCode.GDFood7_952Objects1, "Food7_3": gdjs.GameplayCode.GDFood7_953Objects1, "Food7_4": gdjs.GameplayCode.GDFood7_954Objects1, "Food8_1": gdjs.GameplayCode.GDFood8_951Objects1, "Food8_2": gdjs.GameplayCode.GDFood8_952Objects1, "Food8_3": gdjs.GameplayCode.GDFood8_953Objects1, "Food8_4": gdjs.GameplayCode.GDFood8_954Objects1});gdjs.GameplayCode.eventsList6 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 1;
if( gdjs.GameplayCode.condition0IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
}
}
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 2;
if( gdjs.GameplayCode.condition1IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
}
}
{
gdjs.GameplayCode.condition2IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 3;
if( gdjs.GameplayCode.condition2IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
}
}
{
}
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9994044);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.GameplayCode.GDFood1Objects1, gdjs.GameplayCode.GDFood1Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food1_1"), gdjs.GameplayCode.GDFood1_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food1_2"), gdjs.GameplayCode.GDFood1_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food1_3"), gdjs.GameplayCode.GDFood1_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food1_4"), gdjs.GameplayCode.GDFood1_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood2Objects1, gdjs.GameplayCode.GDFood2Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food2_1"), gdjs.GameplayCode.GDFood2_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food2_2"), gdjs.GameplayCode.GDFood2_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food2_3"), gdjs.GameplayCode.GDFood2_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food2_4"), gdjs.GameplayCode.GDFood2_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood3Objects1, gdjs.GameplayCode.GDFood3Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food3_1"), gdjs.GameplayCode.GDFood3_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food3_2"), gdjs.GameplayCode.GDFood3_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food3_3"), gdjs.GameplayCode.GDFood3_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food3_4"), gdjs.GameplayCode.GDFood3_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood4Objects1, gdjs.GameplayCode.GDFood4Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food4_1"), gdjs.GameplayCode.GDFood4_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food4_2"), gdjs.GameplayCode.GDFood4_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food4_3"), gdjs.GameplayCode.GDFood4_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food4_4"), gdjs.GameplayCode.GDFood4_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood5Objects1, gdjs.GameplayCode.GDFood5Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food5_1"), gdjs.GameplayCode.GDFood5_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food5_2"), gdjs.GameplayCode.GDFood5_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food5_3"), gdjs.GameplayCode.GDFood5_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food5_4"), gdjs.GameplayCode.GDFood5_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood6Objects1, gdjs.GameplayCode.GDFood6Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food6_1"), gdjs.GameplayCode.GDFood6_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food6_2"), gdjs.GameplayCode.GDFood6_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food6_3"), gdjs.GameplayCode.GDFood6_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food6_4"), gdjs.GameplayCode.GDFood6_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood7Objects1, gdjs.GameplayCode.GDFood7Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food7_1"), gdjs.GameplayCode.GDFood7_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food7_2"), gdjs.GameplayCode.GDFood7_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food7_3"), gdjs.GameplayCode.GDFood7_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food7_4"), gdjs.GameplayCode.GDFood7_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood8Objects1, gdjs.GameplayCode.GDFood8Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food8_1"), gdjs.GameplayCode.GDFood8_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food8_2"), gdjs.GameplayCode.GDFood8_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food8_3"), gdjs.GameplayCode.GDFood8_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food8_4"), gdjs.GameplayCode.GDFood8_954Objects2);
gdjs.GameplayCode.GDLifeObjects2.length = 0;

{for(var i = 0, len = gdjs.GameplayCode.GDFood1Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFood1_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_954Objects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDLifeObjects2Objects, 600 + (gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) * 60), 42, "");
}{for(var i = 0, len = gdjs.GameplayCode.GDLifeObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDLifeObjects2[i].setScale(0.5);
}
}{runtimeScene.getVariables().getFromIndex(3).add(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "FailureWarning");
}{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "255;96;96");
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 4;
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9996180);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDFood1Objects1 */
/* Reuse gdjs.GameplayCode.GDFood2Objects1 */
/* Reuse gdjs.GameplayCode.GDFood3Objects1 */
/* Reuse gdjs.GameplayCode.GDFood4Objects1 */
/* Reuse gdjs.GameplayCode.GDFood5Objects1 */
/* Reuse gdjs.GameplayCode.GDFood6Objects1 */
/* Reuse gdjs.GameplayCode.GDFood7Objects1 */
/* Reuse gdjs.GameplayCode.GDFood8Objects1 */
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.GameplayCode.GDScoreObjects1);
gdjs.GameplayCode.GDFood1_951Objects1.length = 0;

gdjs.GameplayCode.GDFood1_952Objects1.length = 0;

gdjs.GameplayCode.GDFood1_953Objects1.length = 0;

gdjs.GameplayCode.GDFood1_954Objects1.length = 0;

gdjs.GameplayCode.GDFood2_951Objects1.length = 0;

gdjs.GameplayCode.GDFood2_952Objects1.length = 0;

gdjs.GameplayCode.GDFood2_953Objects1.length = 0;

gdjs.GameplayCode.GDFood2_954Objects1.length = 0;

gdjs.GameplayCode.GDFood3_951Objects1.length = 0;

gdjs.GameplayCode.GDFood3_952Objects1.length = 0;

gdjs.GameplayCode.GDFood3_953Objects1.length = 0;

gdjs.GameplayCode.GDFood3_954Objects1.length = 0;

gdjs.GameplayCode.GDFood4_951Objects1.length = 0;

gdjs.GameplayCode.GDFood4_952Objects1.length = 0;

gdjs.GameplayCode.GDFood4_953Objects1.length = 0;

gdjs.GameplayCode.GDFood4_954Objects1.length = 0;

gdjs.GameplayCode.GDFood5_951Objects1.length = 0;

gdjs.GameplayCode.GDFood5_952Objects1.length = 0;

gdjs.GameplayCode.GDFood5_953Objects1.length = 0;

gdjs.GameplayCode.GDFood5_954Objects1.length = 0;

gdjs.GameplayCode.GDFood6_951Objects1.length = 0;

gdjs.GameplayCode.GDFood6_952Objects1.length = 0;

gdjs.GameplayCode.GDFood6_953Objects1.length = 0;

gdjs.GameplayCode.GDFood6_954Objects1.length = 0;

gdjs.GameplayCode.GDFood7_951Objects1.length = 0;

gdjs.GameplayCode.GDFood7_952Objects1.length = 0;

gdjs.GameplayCode.GDFood7_953Objects1.length = 0;

gdjs.GameplayCode.GDFood7_954Objects1.length = 0;

gdjs.GameplayCode.GDFood8_951Objects1.length = 0;

gdjs.GameplayCode.GDFood8_952Objects1.length = 0;

gdjs.GameplayCode.GDFood8_953Objects1.length = 0;

gdjs.GameplayCode.GDFood8_954Objects1.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95954Objects1Objects, "Food" + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) + "_" + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)), (( gdjs.GameplayCode.GDFood8Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood7Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood6Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood5Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood4Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood3Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood2Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood1Objects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDFood1Objects1[0].getPointX("")) :gdjs.GameplayCode.GDFood2Objects1[0].getPointX("")) :gdjs.GameplayCode.GDFood3Objects1[0].getPointX("")) :gdjs.GameplayCode.GDFood4Objects1[0].getPointX("")) :gdjs.GameplayCode.GDFood5Objects1[0].getPointX("")) :gdjs.GameplayCode.GDFood6Objects1[0].getPointX("")) :gdjs.GameplayCode.GDFood7Objects1[0].getPointX("")) :gdjs.GameplayCode.GDFood8Objects1[0].getPointX("")), (( gdjs.GameplayCode.GDFood8Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood7Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood6Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood5Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood4Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood3Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood2Objects1.length === 0 ) ? (( gdjs.GameplayCode.GDFood1Objects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDFood1Objects1[0].getPointY("")) :gdjs.GameplayCode.GDFood2Objects1[0].getPointY("")) :gdjs.GameplayCode.GDFood3Objects1[0].getPointY("")) :gdjs.GameplayCode.GDFood4Objects1[0].getPointY("")) :gdjs.GameplayCode.GDFood5Objects1[0].getPointY("")) :gdjs.GameplayCode.GDFood6Objects1[0].getPointY("")) :gdjs.GameplayCode.GDFood7Objects1[0].getPointY("")) :gdjs.GameplayCode.GDFood8Objects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.GameplayCode.GDFood1_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_954Objects1[i].setScale(1.5);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFood1Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8Objects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "FoodPrepared");
}{runtimeScene.getVariables().getFromIndex(2).add(1);
}{for(var i = 0, len = gdjs.GameplayCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)));
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1 + gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) * 0.075);
}}

}


};gdjs.GameplayCode.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Food1"), gdjs.GameplayCode.GDFood1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food2"), gdjs.GameplayCode.GDFood2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food3"), gdjs.GameplayCode.GDFood3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food4"), gdjs.GameplayCode.GDFood4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food5"), gdjs.GameplayCode.GDFood5Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food6"), gdjs.GameplayCode.GDFood6Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food7"), gdjs.GameplayCode.GDFood7Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food8"), gdjs.GameplayCode.GDFood8Objects1);
gdjs.copyArray(runtimeScene.getObjects("Peeler"), gdjs.GameplayCode.GDPeelerObjects1);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPeelerObjects1Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8Objects1Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8Objects1Objects) > 0;
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition2IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9992620);
}
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "OrderTimeLimit");
}
{ //Subevents
gdjs.GameplayCode.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPizzaObjects1Objects = Hashtable.newFrom({"Pizza": gdjs.GameplayCode.GDPizzaObjects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8Objects1Objects = Hashtable.newFrom({"Food1": gdjs.GameplayCode.GDFood1Objects1, "Food2": gdjs.GameplayCode.GDFood2Objects1, "Food3": gdjs.GameplayCode.GDFood3Objects1, "Food4": gdjs.GameplayCode.GDFood4Objects1, "Food5": gdjs.GameplayCode.GDFood5Objects1, "Food6": gdjs.GameplayCode.GDFood6Objects1, "Food7": gdjs.GameplayCode.GDFood7Objects1, "Food8": gdjs.GameplayCode.GDFood8Objects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8Objects1Objects = Hashtable.newFrom({"Food1": gdjs.GameplayCode.GDFood1Objects1, "Food2": gdjs.GameplayCode.GDFood2Objects1, "Food3": gdjs.GameplayCode.GDFood3Objects1, "Food4": gdjs.GameplayCode.GDFood4Objects1, "Food5": gdjs.GameplayCode.GDFood5Objects1, "Food6": gdjs.GameplayCode.GDFood6Objects1, "Food7": gdjs.GameplayCode.GDFood7Objects1, "Food8": gdjs.GameplayCode.GDFood8Objects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDLifeObjects2Objects = Hashtable.newFrom({"Life": gdjs.GameplayCode.GDLifeObjects2});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95954Objects1Objects = Hashtable.newFrom({"Food1_1": gdjs.GameplayCode.GDFood1_951Objects1, "Food1_2": gdjs.GameplayCode.GDFood1_952Objects1, "Food2_2": gdjs.GameplayCode.GDFood2_952Objects1, "Food3_1": gdjs.GameplayCode.GDFood3_951Objects1, "Food3_2": gdjs.GameplayCode.GDFood3_952Objects1, "Food4_1": gdjs.GameplayCode.GDFood4_951Objects1, "Food4_2": gdjs.GameplayCode.GDFood4_952Objects1, "Food2_1": gdjs.GameplayCode.GDFood2_951Objects1, "Food1_3": gdjs.GameplayCode.GDFood1_953Objects1, "Food2_3": gdjs.GameplayCode.GDFood2_953Objects1, "Food3_3": gdjs.GameplayCode.GDFood3_953Objects1, "Food4_3": gdjs.GameplayCode.GDFood4_953Objects1, "Food1_4": gdjs.GameplayCode.GDFood1_954Objects1, "Food2_4": gdjs.GameplayCode.GDFood2_954Objects1, "Food3_4": gdjs.GameplayCode.GDFood3_954Objects1, "Food4_4": gdjs.GameplayCode.GDFood4_954Objects1, "Food5_1": gdjs.GameplayCode.GDFood5_951Objects1, "Food5_2": gdjs.GameplayCode.GDFood5_952Objects1, "Food5_3": gdjs.GameplayCode.GDFood5_953Objects1, "Food5_4": gdjs.GameplayCode.GDFood5_954Objects1, "Food6_1": gdjs.GameplayCode.GDFood6_951Objects1, "Food6_2": gdjs.GameplayCode.GDFood6_952Objects1, "Food6_3": gdjs.GameplayCode.GDFood6_953Objects1, "Food6_4": gdjs.GameplayCode.GDFood6_954Objects1, "Food7_1": gdjs.GameplayCode.GDFood7_951Objects1, "Food7_2": gdjs.GameplayCode.GDFood7_952Objects1, "Food7_3": gdjs.GameplayCode.GDFood7_953Objects1, "Food7_4": gdjs.GameplayCode.GDFood7_954Objects1, "Food8_1": gdjs.GameplayCode.GDFood8_951Objects1, "Food8_2": gdjs.GameplayCode.GDFood8_952Objects1, "Food8_3": gdjs.GameplayCode.GDFood8_953Objects1, "Food8_4": gdjs.GameplayCode.GDFood8_954Objects1});gdjs.GameplayCode.eventsList8 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 2;
if( gdjs.GameplayCode.condition0IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
}
}
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 3;
if( gdjs.GameplayCode.condition1IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
}
}
{
gdjs.GameplayCode.condition2IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 4;
if( gdjs.GameplayCode.condition2IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
}
}
{
}
}
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10000724);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.GameplayCode.GDFood1Objects1, gdjs.GameplayCode.GDFood1Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food1_1"), gdjs.GameplayCode.GDFood1_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food1_2"), gdjs.GameplayCode.GDFood1_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food1_3"), gdjs.GameplayCode.GDFood1_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food1_4"), gdjs.GameplayCode.GDFood1_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood2Objects1, gdjs.GameplayCode.GDFood2Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food2_1"), gdjs.GameplayCode.GDFood2_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food2_2"), gdjs.GameplayCode.GDFood2_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food2_3"), gdjs.GameplayCode.GDFood2_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food2_4"), gdjs.GameplayCode.GDFood2_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood3Objects1, gdjs.GameplayCode.GDFood3Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food3_1"), gdjs.GameplayCode.GDFood3_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food3_2"), gdjs.GameplayCode.GDFood3_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food3_3"), gdjs.GameplayCode.GDFood3_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food3_4"), gdjs.GameplayCode.GDFood3_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood4Objects1, gdjs.GameplayCode.GDFood4Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food4_1"), gdjs.GameplayCode.GDFood4_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food4_2"), gdjs.GameplayCode.GDFood4_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food4_3"), gdjs.GameplayCode.GDFood4_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food4_4"), gdjs.GameplayCode.GDFood4_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood5Objects1, gdjs.GameplayCode.GDFood5Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food5_1"), gdjs.GameplayCode.GDFood5_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food5_2"), gdjs.GameplayCode.GDFood5_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food5_3"), gdjs.GameplayCode.GDFood5_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food5_4"), gdjs.GameplayCode.GDFood5_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood6Objects1, gdjs.GameplayCode.GDFood6Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food6_1"), gdjs.GameplayCode.GDFood6_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food6_2"), gdjs.GameplayCode.GDFood6_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food6_3"), gdjs.GameplayCode.GDFood6_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food6_4"), gdjs.GameplayCode.GDFood6_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood7Objects1, gdjs.GameplayCode.GDFood7Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food7_1"), gdjs.GameplayCode.GDFood7_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food7_2"), gdjs.GameplayCode.GDFood7_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food7_3"), gdjs.GameplayCode.GDFood7_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food7_4"), gdjs.GameplayCode.GDFood7_954Objects2);
gdjs.copyArray(gdjs.GameplayCode.GDFood8Objects1, gdjs.GameplayCode.GDFood8Objects2);

gdjs.copyArray(runtimeScene.getObjects("Food8_1"), gdjs.GameplayCode.GDFood8_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food8_2"), gdjs.GameplayCode.GDFood8_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food8_3"), gdjs.GameplayCode.GDFood8_953Objects2);
gdjs.copyArray(runtimeScene.getObjects("Food8_4"), gdjs.GameplayCode.GDFood8_954Objects2);
gdjs.GameplayCode.GDLifeObjects2.length = 0;

{for(var i = 0, len = gdjs.GameplayCode.GDFood1Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFood1_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_954Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_951Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_952Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_952Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_953Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_953Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_954Objects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_954Objects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDLifeObjects2Objects, 600 + (gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) * 60), 62, "");
}{for(var i = 0, len = gdjs.GameplayCode.GDLifeObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDLifeObjects2[i].setScale(0.5);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "FailureWarning");
}{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "255;96;96");
}{runtimeScene.getVariables().getFromIndex(3).add(1);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 1;
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10002812);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDFood1Objects1 */
/* Reuse gdjs.GameplayCode.GDFood2Objects1 */
/* Reuse gdjs.GameplayCode.GDFood3Objects1 */
/* Reuse gdjs.GameplayCode.GDFood4Objects1 */
/* Reuse gdjs.GameplayCode.GDFood5Objects1 */
/* Reuse gdjs.GameplayCode.GDFood6Objects1 */
/* Reuse gdjs.GameplayCode.GDFood7Objects1 */
/* Reuse gdjs.GameplayCode.GDFood8Objects1 */
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.GameplayCode.GDScoreObjects1);
gdjs.GameplayCode.GDFood1_951Objects1.length = 0;

gdjs.GameplayCode.GDFood1_952Objects1.length = 0;

gdjs.GameplayCode.GDFood1_953Objects1.length = 0;

gdjs.GameplayCode.GDFood1_954Objects1.length = 0;

gdjs.GameplayCode.GDFood2_951Objects1.length = 0;

gdjs.GameplayCode.GDFood2_952Objects1.length = 0;

gdjs.GameplayCode.GDFood2_953Objects1.length = 0;

gdjs.GameplayCode.GDFood2_954Objects1.length = 0;

gdjs.GameplayCode.GDFood3_951Objects1.length = 0;

gdjs.GameplayCode.GDFood3_952Objects1.length = 0;

gdjs.GameplayCode.GDFood3_953Objects1.length = 0;

gdjs.GameplayCode.GDFood3_954Objects1.length = 0;

gdjs.GameplayCode.GDFood4_951Objects1.length = 0;

gdjs.GameplayCode.GDFood4_952Objects1.length = 0;

gdjs.GameplayCode.GDFood4_953Objects1.length = 0;

gdjs.GameplayCode.GDFood4_954Objects1.length = 0;

gdjs.GameplayCode.GDFood5_951Objects1.length = 0;

gdjs.GameplayCode.GDFood5_952Objects1.length = 0;

gdjs.GameplayCode.GDFood5_953Objects1.length = 0;

gdjs.GameplayCode.GDFood5_954Objects1.length = 0;

gdjs.GameplayCode.GDFood6_951Objects1.length = 0;

gdjs.GameplayCode.GDFood6_952Objects1.length = 0;

gdjs.GameplayCode.GDFood6_953Objects1.length = 0;

gdjs.GameplayCode.GDFood6_954Objects1.length = 0;

gdjs.GameplayCode.GDFood7_951Objects1.length = 0;

gdjs.GameplayCode.GDFood7_952Objects1.length = 0;

gdjs.GameplayCode.GDFood7_953Objects1.length = 0;

gdjs.GameplayCode.GDFood7_954Objects1.length = 0;

gdjs.GameplayCode.GDFood8_951Objects1.length = 0;

gdjs.GameplayCode.GDFood8_952Objects1.length = 0;

gdjs.GameplayCode.GDFood8_953Objects1.length = 0;

gdjs.GameplayCode.GDFood8_954Objects1.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95954Objects1Objects, "Food" + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) + "_" + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)), 340, 440, "");
}{for(var i = 0, len = gdjs.GameplayCode.GDFood1_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_954Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_951Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_952Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_953Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_954Objects1[i].setScale(1.5);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFood1Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8Objects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "FoodPrepared");
}{runtimeScene.getVariables().getFromIndex(2).add(1);
}{for(var i = 0, len = gdjs.GameplayCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)));
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1 + gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) * 0.075);
}}

}


};gdjs.GameplayCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Food1"), gdjs.GameplayCode.GDFood1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food2"), gdjs.GameplayCode.GDFood2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food3"), gdjs.GameplayCode.GDFood3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food4"), gdjs.GameplayCode.GDFood4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food5"), gdjs.GameplayCode.GDFood5Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food6"), gdjs.GameplayCode.GDFood6Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food7"), gdjs.GameplayCode.GDFood7Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food8"), gdjs.GameplayCode.GDFood8Objects1);
gdjs.copyArray(runtimeScene.getObjects("Pizza"), gdjs.GameplayCode.GDPizzaObjects1);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDPizzaObjects1Objects, gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8Objects1Objects, false, runtimeScene, false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8Objects1Objects) > 0;
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition2IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9999300);
}
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "OrderTimeLimit");
}
{ //Subevents
gdjs.GameplayCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8Objects1Objects = Hashtable.newFrom({"Food1": gdjs.GameplayCode.GDFood1Objects1, "Food2": gdjs.GameplayCode.GDFood2Objects1, "Food3": gdjs.GameplayCode.GDFood3Objects1, "Food4": gdjs.GameplayCode.GDFood4Objects1, "Food5": gdjs.GameplayCode.GDFood5Objects1, "Food6": gdjs.GameplayCode.GDFood6Objects1, "Food7": gdjs.GameplayCode.GDFood7Objects1, "Food8": gdjs.GameplayCode.GDFood8Objects1});gdjs.GameplayCode.eventsList10 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDFood1Objects1 */
/* Reuse gdjs.GameplayCode.GDFood2Objects1 */
/* Reuse gdjs.GameplayCode.GDFood3Objects1 */
/* Reuse gdjs.GameplayCode.GDFood4Objects1 */
/* Reuse gdjs.GameplayCode.GDFood5Objects1 */
/* Reuse gdjs.GameplayCode.GDFood6Objects1 */
/* Reuse gdjs.GameplayCode.GDFood7Objects1 */
/* Reuse gdjs.GameplayCode.GDFood8Objects1 */
{for(var i = 0, len = gdjs.GameplayCode.GDFood1Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1Objects1[i].clearForces();
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2Objects1[i].clearForces();
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3Objects1[i].clearForces();
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4Objects1[i].clearForces();
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5Objects1[i].clearForces();
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6Objects1[i].clearForces();
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7Objects1[i].clearForces();
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8Objects1[i].clearForces();
}
}}

}


};gdjs.GameplayCode.eventsList11 = function(runtimeScene) {

};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDGameOverMenuObjects1Objects = Hashtable.newFrom({"GameOverMenu": gdjs.GameplayCode.GDGameOverMenuObjects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDGameOverTextObjects1Objects = Hashtable.newFrom({"GameOverText": gdjs.GameplayCode.GDGameOverTextObjects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDGameOverScoreObjects1Objects = Hashtable.newFrom({"GameOverScore": gdjs.GameplayCode.GDGameOverScoreObjects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDUsernameHintObjects1Objects = Hashtable.newFrom({"UsernameHint": gdjs.GameplayCode.GDUsernameHintObjects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDUsernameObjects1Objects = Hashtable.newFrom({"Username": gdjs.GameplayCode.GDUsernameObjects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDSaveScoreObjects1Objects = Hashtable.newFrom({"SaveScore": gdjs.GameplayCode.GDSaveScoreObjects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDRestartButtonObjects1Objects = Hashtable.newFrom({"RestartButton": gdjs.GameplayCode.GDRestartButtonObjects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDMenuButtonObjects1Objects = Hashtable.newFrom({"MenuButton": gdjs.GameplayCode.GDMenuButtonObjects1});gdjs.GameplayCode.eventsList12 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().getFromIndex(4), false);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10006972);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.GameplayCode.GDGameOverMenuObjects1.length = 0;

gdjs.GameplayCode.GDGameOverScoreObjects1.length = 0;

gdjs.GameplayCode.GDGameOverTextObjects1.length = 0;

gdjs.GameplayCode.GDMenuButtonObjects1.length = 0;

gdjs.GameplayCode.GDRestartButtonObjects1.length = 0;

gdjs.GameplayCode.GDSaveScoreObjects1.length = 0;

gdjs.GameplayCode.GDUsernameObjects1.length = 0;

gdjs.GameplayCode.GDUsernameHintObjects1.length = 0;

{gdjs.evtTools.common.setVariableBoolean(runtimeScene.getVariables().getFromIndex(8), true);
}{runtimeScene.getGame().getVariables().getFromIndex(10).add(Math.round(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(11)) * gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2))));
}{gdjs.evtTools.common.setVariableBoolean(runtimeScene.getVariables().getFromIndex(7), false);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDGameOverMenuObjects1Objects, 95, 150, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDGameOverTextObjects1Objects, 315, 200, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDGameOverScoreObjects1Objects, 335, 250, "");
}{for(var i = 0, len = gdjs.GameplayCode.GDGameOverScoreObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDGameOverScoreObjects1[i].setString(gdjs.GameplayCode.GDGameOverScoreObjects1[i].getString() + (gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2))));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDUsernameHintObjects1Objects, 335, 275, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDUsernameObjects1Objects, 350, 275, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDSaveScoreObjects1Objects, 370, 315, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDRestartButtonObjects1Objects, 300, 400, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDMenuButtonObjects1Objects, 425, 400, "");
}{for(var i = 0, len = gdjs.GameplayCode.GDGameOverMenuObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDGameOverMenuObjects1[i].setZOrder(90);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDGameOverTextObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDGameOverTextObjects1[i].setZOrder(100);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDGameOverScoreObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDGameOverScoreObjects1[i].setZOrder(100);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDUsernameHintObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDUsernameHintObjects1[i].setZOrder(100);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDSaveScoreObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDSaveScoreObjects1[i].setZOrder(100);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDRestartButtonObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDRestartButtonObjects1[i].setZOrder(100);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDMenuButtonObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDMenuButtonObjects1[i].setZOrder(100);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDSaveScoreObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDSaveScoreObjects1[i].setScale(0.03);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDRestartButtonObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDRestartButtonObjects1[i].setScale(0.04);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDMenuButtonObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDMenuButtonObjects1[i].setScale(0.04);
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDLifeObjects1Objects = Hashtable.newFrom({"Life": gdjs.GameplayCode.GDLifeObjects1});gdjs.GameplayCode.eventsList13 = function(runtimeScene) {

};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDEscMenuObjects1Objects = Hashtable.newFrom({"EscMenu": gdjs.GameplayCode.GDEscMenuObjects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDEscMenuTextObjects1Objects = Hashtable.newFrom({"EscMenuText": gdjs.GameplayCode.GDEscMenuTextObjects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDContinueButtonObjects1Objects = Hashtable.newFrom({"ContinueButton": gdjs.GameplayCode.GDContinueButtonObjects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDMenuButtonObjects1Objects = Hashtable.newFrom({"MenuButton": gdjs.GameplayCode.GDMenuButtonObjects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDRestartButtonObjects1Objects = Hashtable.newFrom({"RestartButton": gdjs.GameplayCode.GDRestartButtonObjects1});gdjs.GameplayCode.eventsList14 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().getFromIndex(8), false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("MenuButton"), gdjs.GameplayCode.GDMenuButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("RestartButton"), gdjs.GameplayCode.GDRestartButtonObjects1);
{for(var i = 0, len = gdjs.GameplayCode.GDRestartButtonObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDRestartButtonObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDMenuButtonObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDMenuButtonObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1 + gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) * 0.075);
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDContinueButtonObjects1Objects = Hashtable.newFrom({"ContinueButton": gdjs.GameplayCode.GDContinueButtonObjects1});gdjs.GameplayCode.eventsList15 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.common.toggleVariableBoolean(runtimeScene.getVariables().getFromIndex(7));
}}

}


};gdjs.GameplayCode.eventsList16 = function(runtimeScene) {

};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDRestartButtonObjects1Objects = Hashtable.newFrom({"RestartButton": gdjs.GameplayCode.GDRestartButtonObjects1});gdjs.GameplayCode.eventsList17 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Gameplay", true);
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDMenuButtonObjects1Objects = Hashtable.newFrom({"MenuButton": gdjs.GameplayCode.GDMenuButtonObjects1});gdjs.GameplayCode.eventsList18 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", true);
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDSaveScoreObjects1Objects = Hashtable.newFrom({"SaveScore": gdjs.GameplayCode.GDSaveScoreObjects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDScoreSavedObjects1Objects = Hashtable.newFrom({"ScoreSaved": gdjs.GameplayCode.GDScoreSavedObjects1});gdjs.GameplayCode.eventsList19 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) > gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("score10"));
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(6).sub(1);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) > gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("score9"));
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(6).sub(1);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) > gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("score8"));
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(6).sub(1);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) > gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("score7"));
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(6).sub(1);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) > gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("score6"));
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(6).sub(1);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) > gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("score5"));
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(6).sub(1);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) > gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("score4"));
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(6).sub(1);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) > gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("score3"));
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(6).sub(1);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) > gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("score2"));
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(6).sub(1);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) > gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("score1"));
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(6).sub(1);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(6)) != 11;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.GameplayCode.GDUsernameObjects1, gdjs.GameplayCode.GDUsernameObjects2);

{gdjs.evtTools.firebase.firestore.updateField("highscores", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(6)), "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(6)), "name", (( gdjs.GameplayCode.GDUsernameObjects2.length === 0 ) ? "" :gdjs.GameplayCode.GDUsernameObjects2[0].getString()), gdjs.VariablesContainer.badVariable);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(6)) == 1;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.firebase.firestore.updateField("highscores", "2", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score1")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "2", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player1")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "3", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score2")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "3", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player2")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "4", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score3")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "4", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player3")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "5", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score4")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "5", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player4")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "6", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score5")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "6", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player5")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "7", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score6")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "7", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player6")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "8", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score7")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "8", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player7")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "9", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score8")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "9", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player8")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "10", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score9")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "10", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player9")), gdjs.VariablesContainer.badVariable);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(6)) == 2;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.firebase.firestore.updateField("highscores", "3", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score2")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "3", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player2")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "4", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score3")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "4", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player3")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "5", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score4")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "5", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player4")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "6", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score5")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "6", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player5")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "7", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score6")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "7", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player6")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "8", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score7")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "8", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player7")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "9", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score8")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "9", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player8")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "10", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score9")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "10", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player9")), gdjs.VariablesContainer.badVariable);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(6)) == 3;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.firebase.firestore.updateField("highscores", "4", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score3")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "4", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player3")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "5", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score4")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "5", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player4")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "6", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score5")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "6", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player5")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "7", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score6")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "7", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player6")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "8", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score7")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "8", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player7")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "9", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score8")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "9", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player8")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "10", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score9")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "10", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player9")), gdjs.VariablesContainer.badVariable);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(6)) == 4;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.firebase.firestore.updateField("highscores", "5", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score4")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "5", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player4")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "6", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score5")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "6", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player5")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "7", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score6")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "7", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player6")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "8", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score7")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "8", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player7")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "9", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score8")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "9", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player8")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "10", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score9")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "10", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player9")), gdjs.VariablesContainer.badVariable);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(6)) == 5;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.firebase.firestore.updateField("highscores", "6", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score5")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "6", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player5")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "7", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score6")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "7", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player6")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "8", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score7")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "8", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player7")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "9", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score8")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "9", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player8")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "10", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score9")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "10", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player9")), gdjs.VariablesContainer.badVariable);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(6)) == 6;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.firebase.firestore.updateField("highscores", "7", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score6")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "7", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player6")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "8", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score7")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "8", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player7")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "9", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score8")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "9", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player8")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "10", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score9")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "10", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player9")), gdjs.VariablesContainer.badVariable);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(6)) == 7;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.firebase.firestore.updateField("highscores", "8", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score7")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "8", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player7")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "9", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score8")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "9", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player8")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "10", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score9")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "10", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player9")), gdjs.VariablesContainer.badVariable);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(6)) == 8;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.firebase.firestore.updateField("highscores", "9", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score8")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "9", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player8")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "10", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score9")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "10", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player9")), gdjs.VariablesContainer.badVariable);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(6)) == 9;
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.firebase.firestore.updateField("highscores", "10", "score", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("score9")), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.updateField("highscores", "10", "name", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("player9")), gdjs.VariablesContainer.badVariable);
}}

}


{


{
}

}


};gdjs.GameplayCode.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Username"), gdjs.GameplayCode.GDUsernameObjects1);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUsernameObjects1.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUsernameObjects1[i].getString() == "") ) {
        gdjs.GameplayCode.condition1IsTrue_0.val = true;
        gdjs.GameplayCode.GDUsernameObjects1[k] = gdjs.GameplayCode.GDUsernameObjects1[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUsernameObjects1.length = k;}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition2IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10029068);
}
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
gdjs.GameplayCode.GDScoreSavedObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDScoreSavedObjects1Objects, 450, 340, "");
}{for(var i = 0, len = gdjs.GameplayCode.GDScoreSavedObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDScoreSavedObjects1[i].setZOrder(100);
}
}
{ //Subevents
gdjs.GameplayCode.eventsList19(runtimeScene);} //End of subevents
}

}


};gdjs.GameplayCode.eventsList21 = function(runtimeScene) {

};gdjs.GameplayCode.eventsList22 = function(runtimeScene) {

{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10072852);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.GameplayCode.GDScoreObjects2);
{runtimeScene.getVariables().getFromIndex(2).add(50);
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1 + gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) * 0.075);
}{for(var i = 0, len = gdjs.GameplayCode.GDScoreObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDScoreObjects2[i].setString("Score: " + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)));
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10074188);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{gdjs.evtTools.common.toggleVariableBoolean(runtimeScene.getVariables().getFromIndex(4));
}}

}


};gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDVulnerabilityObjects1Objects = Hashtable.newFrom({"Vulnerability": gdjs.GameplayCode.GDVulnerabilityObjects1});gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDStatistics1Objects1Objects = Hashtable.newFrom({"Statistics1": gdjs.GameplayCode.GDStatistics1Objects1});gdjs.GameplayCode.eventsList23 = function(runtimeScene) {

{



}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9967308);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{gdjs.evtTools.firebase.firestore.getField("highscores", "1", "name", runtimeScene.getVariables().get("player1"), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.getField("highscores", "1", "score", runtimeScene.getVariables().get("score1"), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.getField("highscores", "2", "name", runtimeScene.getVariables().get("player2"), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.getField("highscores", "2", "score", runtimeScene.getVariables().get("score2"), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.getField("highscores", "3", "name", runtimeScene.getVariables().get("player3"), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.getField("highscores", "3", "score", runtimeScene.getVariables().get("score3"), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.getField("highscores", "4", "name", runtimeScene.getVariables().get("player4"), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.getField("highscores", "4", "score", runtimeScene.getVariables().get("score4"), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.getField("highscores", "5", "name", runtimeScene.getVariables().get("player5"), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.getField("highscores", "5", "score", runtimeScene.getVariables().get("score5"), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.getField("highscores", "6", "name", runtimeScene.getVariables().get("player6"), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.getField("highscores", "6", "score", runtimeScene.getVariables().get("score6"), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.getField("highscores", "7", "name", runtimeScene.getVariables().get("player7"), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.getField("highscores", "7", "score", runtimeScene.getVariables().get("score7"), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.getField("highscores", "8", "name", runtimeScene.getVariables().get("player8"), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.getField("highscores", "8", "score", runtimeScene.getVariables().get("score8"), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.getField("highscores", "9", "name", runtimeScene.getVariables().get("player9"), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.getField("highscores", "9", "score", runtimeScene.getVariables().get("score9"), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.getField("highscores", "10", "name", runtimeScene.getVariables().get("player10"), gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.firebase.firestore.getField("highscores", "10", "score", runtimeScene.getVariables().get("score10"), gdjs.VariablesContainer.badVariable);
}}

}


{


gdjs.GameplayCode.eventsList0(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Food1"), gdjs.GameplayCode.GDFood1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food2"), gdjs.GameplayCode.GDFood2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food3"), gdjs.GameplayCode.GDFood3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food4"), gdjs.GameplayCode.GDFood4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food5"), gdjs.GameplayCode.GDFood5Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food6"), gdjs.GameplayCode.GDFood6Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food7"), gdjs.GameplayCode.GDFood7Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food8"), gdjs.GameplayCode.GDFood8Objects1);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
gdjs.GameplayCode.condition2IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2, "FoodCreation");
}if ( gdjs.GameplayCode.condition0IsTrue_1.val ) {
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.3, "FoodPrepared");
}if ( gdjs.GameplayCode.condition1IsTrue_1.val ) {
{
gdjs.GameplayCode.condition2IsTrue_1.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8Objects1Objects) < 1;
}}
}
gdjs.GameplayCode.conditionTrue_1.val = true && gdjs.GameplayCode.condition0IsTrue_1.val && gdjs.GameplayCode.condition1IsTrue_1.val && gdjs.GameplayCode.condition2IsTrue_1.val;
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Food1_1"), gdjs.GameplayCode.GDFood1_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food1_2"), gdjs.GameplayCode.GDFood1_952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food1_3"), gdjs.GameplayCode.GDFood1_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food1_4"), gdjs.GameplayCode.GDFood1_954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food2_1"), gdjs.GameplayCode.GDFood2_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food2_2"), gdjs.GameplayCode.GDFood2_952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food2_3"), gdjs.GameplayCode.GDFood2_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food2_4"), gdjs.GameplayCode.GDFood2_954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food3_1"), gdjs.GameplayCode.GDFood3_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food3_2"), gdjs.GameplayCode.GDFood3_952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food3_3"), gdjs.GameplayCode.GDFood3_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food3_4"), gdjs.GameplayCode.GDFood3_954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food4_1"), gdjs.GameplayCode.GDFood4_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food4_2"), gdjs.GameplayCode.GDFood4_952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food4_3"), gdjs.GameplayCode.GDFood4_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food4_4"), gdjs.GameplayCode.GDFood4_954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food5_1"), gdjs.GameplayCode.GDFood5_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food5_2"), gdjs.GameplayCode.GDFood5_952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food5_3"), gdjs.GameplayCode.GDFood5_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food5_4"), gdjs.GameplayCode.GDFood5_954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food6_1"), gdjs.GameplayCode.GDFood6_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food6_2"), gdjs.GameplayCode.GDFood6_952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food6_3"), gdjs.GameplayCode.GDFood6_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food6_4"), gdjs.GameplayCode.GDFood6_954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food7_1"), gdjs.GameplayCode.GDFood7_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food7_2"), gdjs.GameplayCode.GDFood7_952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food7_3"), gdjs.GameplayCode.GDFood7_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food7_4"), gdjs.GameplayCode.GDFood7_954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food8_1"), gdjs.GameplayCode.GDFood8_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food8_2"), gdjs.GameplayCode.GDFood8_952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food8_3"), gdjs.GameplayCode.GDFood8_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food8_4"), gdjs.GameplayCode.GDFood8_954Objects1);
gdjs.copyArray(runtimeScene.getObjects("OrderDisplay"), gdjs.GameplayCode.GDOrderDisplayObjects1);
/* Reuse gdjs.GameplayCode.GDFood1Objects1 */
/* Reuse gdjs.GameplayCode.GDFood2Objects1 */
/* Reuse gdjs.GameplayCode.GDFood3Objects1 */
/* Reuse gdjs.GameplayCode.GDFood4Objects1 */
/* Reuse gdjs.GameplayCode.GDFood5Objects1 */
/* Reuse gdjs.GameplayCode.GDFood6Objects1 */
/* Reuse gdjs.GameplayCode.GDFood7Objects1 */
/* Reuse gdjs.GameplayCode.GDFood8Objects1 */
gdjs.GameplayCode.GDProgressObjects1.length = 0;

{for(var i = 0, len = gdjs.GameplayCode.GDFood1_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_951Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_952Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_952Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_951Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_952Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_951Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_952Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_951Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_953Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_953Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_953Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_953Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_954Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_954Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_954Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_954Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_951Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_952Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_953Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_954Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_951Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_952Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_953Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_954Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_951Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_952Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_953Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_954Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_951Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_952Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_953Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_954Objects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getVariables().getFromIndex(0).setNumber((gdjs.randomInRange(1, gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)))));
}{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8Objects1Objects, "Food" + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)), 400 - 72, 300 - 89, "");
}{for(var i = 0, len = gdjs.GameplayCode.GDFood1Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7Objects1[i].setScale(1.5);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8Objects1[i].setScale(1.5);
}
}{runtimeScene.getVariables().getFromIndex(1).setNumber((gdjs.randomInRange(1, 4)));
}{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood1_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7_95954Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95951Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95952Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95953Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8_95954Objects1Objects, "Food" + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) + "_" + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)), (( gdjs.GameplayCode.GDOrderDisplayObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDOrderDisplayObjects1[0].getPointX("")) + 50, (( gdjs.GameplayCode.GDOrderDisplayObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDOrderDisplayObjects1[0].getPointY("")) + 60, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDProgressObjects1Objects, (( gdjs.GameplayCode.GDOrderDisplayObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDOrderDisplayObjects1[0].getPointX("")), (( gdjs.GameplayCode.GDOrderDisplayObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDOrderDisplayObjects1[0].getPointY("")) + 193, "");
}{for(var i = 0, len = gdjs.GameplayCode.GDProgressObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDProgressObjects1[i].setHeight(8);
}
}{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "OrderTimeLimit");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "OrderTimeLimit");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "FoodCreation");
}}

}


{


gdjs.GameplayCode.eventsList1(runtimeScene);
}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameplayCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameplayCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameplayCode.eventsList7(runtimeScene);} //End of subevents
}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameplayCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Food1"), gdjs.GameplayCode.GDFood1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food2"), gdjs.GameplayCode.GDFood2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food3"), gdjs.GameplayCode.GDFood3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food4"), gdjs.GameplayCode.GDFood4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food5"), gdjs.GameplayCode.GDFood5Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food6"), gdjs.GameplayCode.GDFood6Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food7"), gdjs.GameplayCode.GDFood7Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food8"), gdjs.GameplayCode.GDFood8Objects1);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDFood1Objects1ObjectsGDgdjs_46GameplayCode_46GDFood2Objects1ObjectsGDgdjs_46GameplayCode_46GDFood3Objects1ObjectsGDgdjs_46GameplayCode_46GDFood4Objects1ObjectsGDgdjs_46GameplayCode_46GDFood5Objects1ObjectsGDgdjs_46GameplayCode_46GDFood6Objects1ObjectsGDgdjs_46GameplayCode_46GDFood7Objects1ObjectsGDgdjs_46GameplayCode_46GDFood8Objects1Objects, runtimeScene, true, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameplayCode.eventsList10(runtimeScene);} //End of subevents
}

}


{


gdjs.GameplayCode.eventsList11(runtimeScene);
}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)) < 5;
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8488964);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(11).setNumber(1);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)) == 5;
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9263284);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(11).add(0.25);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)) == 6;
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8859916);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(11).add(0.25);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)) == 7;
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9261564);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(11).add(0.25);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)) == 8;
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10690164);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(11).add(0.5);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) >= 3;
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9544940);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.GameplayCode.eventsList12(runtimeScene);} //End of subevents
}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.3, "FailureWarning");
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "74;144;226");
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 10, "OrderTimeLimit");
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10013404);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Food1"), gdjs.GameplayCode.GDFood1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food1_1"), gdjs.GameplayCode.GDFood1_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food1_2"), gdjs.GameplayCode.GDFood1_952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food1_3"), gdjs.GameplayCode.GDFood1_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food1_4"), gdjs.GameplayCode.GDFood1_954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food2"), gdjs.GameplayCode.GDFood2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food2_1"), gdjs.GameplayCode.GDFood2_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food2_2"), gdjs.GameplayCode.GDFood2_952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food2_3"), gdjs.GameplayCode.GDFood2_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food2_4"), gdjs.GameplayCode.GDFood2_954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food3"), gdjs.GameplayCode.GDFood3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food3_1"), gdjs.GameplayCode.GDFood3_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food3_2"), gdjs.GameplayCode.GDFood3_952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food3_3"), gdjs.GameplayCode.GDFood3_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food3_4"), gdjs.GameplayCode.GDFood3_954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food4"), gdjs.GameplayCode.GDFood4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food4_1"), gdjs.GameplayCode.GDFood4_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food4_2"), gdjs.GameplayCode.GDFood4_952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food4_3"), gdjs.GameplayCode.GDFood4_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food4_4"), gdjs.GameplayCode.GDFood4_954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food5"), gdjs.GameplayCode.GDFood5Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food5_1"), gdjs.GameplayCode.GDFood5_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food5_2"), gdjs.GameplayCode.GDFood5_952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food5_3"), gdjs.GameplayCode.GDFood5_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food5_4"), gdjs.GameplayCode.GDFood5_954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food6"), gdjs.GameplayCode.GDFood6Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food6_1"), gdjs.GameplayCode.GDFood6_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food6_2"), gdjs.GameplayCode.GDFood6_952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food6_3"), gdjs.GameplayCode.GDFood6_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food6_4"), gdjs.GameplayCode.GDFood6_954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food7"), gdjs.GameplayCode.GDFood7Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food7_1"), gdjs.GameplayCode.GDFood7_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food7_2"), gdjs.GameplayCode.GDFood7_952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food7_3"), gdjs.GameplayCode.GDFood7_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food7_4"), gdjs.GameplayCode.GDFood7_954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food8"), gdjs.GameplayCode.GDFood8Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food8_1"), gdjs.GameplayCode.GDFood8_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food8_2"), gdjs.GameplayCode.GDFood8_952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food8_3"), gdjs.GameplayCode.GDFood8_953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Food8_4"), gdjs.GameplayCode.GDFood8_954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Progress"), gdjs.GameplayCode.GDProgressObjects1);
gdjs.GameplayCode.GDLifeObjects1.length = 0;

{for(var i = 0, len = gdjs.GameplayCode.GDFood1_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_951Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_952Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_952Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_951Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_952Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_951Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_952Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_951Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_953Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_953Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_953Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_953Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood1_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1_954Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2_954Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3_954Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4_954Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_951Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_952Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_953Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5_954Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_951Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_952Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_953Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6_954Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_951Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_952Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_953Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7_954Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_951Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_951Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_952Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_952Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_953Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_953Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8_954Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8_954Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDFood1Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood1Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood2Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood2Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood3Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood3Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood4Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood4Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood5Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood5Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood6Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood6Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood7Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood7Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameplayCode.GDFood8Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDFood8Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDProgressObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDProgressObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "FailureWarning");
}{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "255;96;96");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDLifeObjects1Objects, 600 + (gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) * 60), 62, "");
}{for(var i = 0, len = gdjs.GameplayCode.GDLifeObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDLifeObjects1[i].setScale(0.5);
}
}{runtimeScene.getVariables().getFromIndex(3).add(1);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Progress"), gdjs.GameplayCode.GDProgressObjects1);
{for(var i = 0, len = gdjs.GameplayCode.GDProgressObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDProgressObjects1[i].setWidth(gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "OrderTimeLimit") * 20);
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "410574__yummie__game-background-music-loop-short.mp3", true, (gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) + 1) * 50, 1);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
gdjs.GameplayCode.condition2IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10016956);
}
}if ( gdjs.GameplayCode.condition1IsTrue_0.val ) {
{
gdjs.GameplayCode.condition2IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().getFromIndex(8), false);
}}
}
if (gdjs.GameplayCode.condition2IsTrue_0.val) {
{gdjs.evtTools.common.toggleVariableBoolean(runtimeScene.getVariables().getFromIndex(7));
}}

}


{


gdjs.GameplayCode.eventsList13(runtimeScene);
}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().getFromIndex(7), true);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.GameplayCode.GDContinueButtonObjects1.length = 0;

gdjs.GameplayCode.GDEscMenuObjects1.length = 0;

gdjs.GameplayCode.GDEscMenuTextObjects1.length = 0;

gdjs.GameplayCode.GDMenuButtonObjects1.length = 0;

gdjs.GameplayCode.GDRestartButtonObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDEscMenuObjects1Objects, 95, 150, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDEscMenuTextObjects1Objects, 350, 200, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDContinueButtonObjects1Objects, 325, 275, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDMenuButtonObjects1Objects, 425, 400, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDRestartButtonObjects1Objects, 300, 400, "");
}{for(var i = 0, len = gdjs.GameplayCode.GDEscMenuObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDEscMenuObjects1[i].setZOrder(90);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDEscMenuTextObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDEscMenuTextObjects1[i].setZOrder(100);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDMenuButtonObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDMenuButtonObjects1[i].setZOrder(100);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDContinueButtonObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDContinueButtonObjects1[i].setZOrder(100);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDRestartButtonObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDRestartButtonObjects1[i].setZOrder(100);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDRestartButtonObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDRestartButtonObjects1[i].setScale(0.04);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDMenuButtonObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDMenuButtonObjects1[i].setScale(0.04);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDContinueButtonObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDContinueButtonObjects1[i].setScale(0.04);
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().getFromIndex(7), false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ContinueButton"), gdjs.GameplayCode.GDContinueButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("EscMenu"), gdjs.GameplayCode.GDEscMenuObjects1);
gdjs.copyArray(runtimeScene.getObjects("EscMenuText"), gdjs.GameplayCode.GDEscMenuTextObjects1);
{for(var i = 0, len = gdjs.GameplayCode.GDEscMenuObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDEscMenuObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDContinueButtonObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDContinueButtonObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameplayCode.GDEscMenuTextObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDEscMenuTextObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.GameplayCode.eventsList14(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ContinueButton"), gdjs.GameplayCode.GDContinueButtonObjects1);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDContinueButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameplayCode.eventsList15(runtimeScene);} //End of subevents
}

}


{


gdjs.GameplayCode.eventsList16(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Username"), gdjs.GameplayCode.GDUsernameObjects1);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameplayCode.GDUsernameObjects1.length;i<l;++i) {
    if ( !(gdjs.GameplayCode.GDUsernameObjects1[i].getString() == "") ) {
        gdjs.GameplayCode.condition0IsTrue_0.val = true;
        gdjs.GameplayCode.GDUsernameObjects1[k] = gdjs.GameplayCode.GDUsernameObjects1[i];
        ++k;
    }
}
gdjs.GameplayCode.GDUsernameObjects1.length = k;}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameplayCode.GDUsernameObjects1 */
gdjs.copyArray(runtimeScene.getObjects("UsernameHint"), gdjs.GameplayCode.GDUsernameHintObjects1);
{for(var i = 0, len = gdjs.GameplayCode.GDUsernameHintObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDUsernameHintObjects1[i].setString(gdjs.evtTools.string.subStr((( gdjs.GameplayCode.GDUsernameObjects1.length === 0 ) ? "" :gdjs.GameplayCode.GDUsernameObjects1[0].getString()), 0, 10));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("RestartButton"), gdjs.GameplayCode.GDRestartButtonObjects1);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDRestartButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameplayCode.eventsList17(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MenuButton"), gdjs.GameplayCode.GDMenuButtonObjects1);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDMenuButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameplayCode.eventsList18(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("SaveScore"), gdjs.GameplayCode.GDSaveScoreObjects1);

gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDSaveScoreObjects1Objects, runtimeScene, true, false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameplayCode.eventsList20(runtimeScene);} //End of subevents
}

}


{


gdjs.GameplayCode.eventsList21(runtimeScene);
}


{



}


{



}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Statistics1"), gdjs.GameplayCode.GDStatistics1Objects1);
{runtimeScene.getVariables().getFromIndex(10).setNumber(Math.round(gdjs.evtTools.runtimeScene.getTimeFromStartInSeconds(runtimeScene)));
}{for(var i = 0, len = gdjs.GameplayCode.GDStatistics1Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDStatistics1Objects1[i].setString("Seconds Elapsed: " + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(10)));
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LShift");
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
gdjs.GameplayCode.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "RShift");
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "OrderTimeLimit");
}
{ //Subevents
gdjs.GameplayCode.eventsList22(runtimeScene);} //End of subevents
}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition0IsTrue_0;
gdjs.GameplayCode.condition0IsTrue_1.val = false;
gdjs.GameplayCode.condition1IsTrue_1.val = false;
{
gdjs.GameplayCode.condition0IsTrue_1.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "RShift");
if( gdjs.GameplayCode.condition0IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
}
}
{
gdjs.GameplayCode.condition1IsTrue_1.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "LShift");
if( gdjs.GameplayCode.condition1IsTrue_1.val ) {
    gdjs.GameplayCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "OrderTimeLimit");
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().getFromIndex(4), true);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Life"), gdjs.GameplayCode.GDLifeObjects1);
gdjs.GameplayCode.GDVulnerabilityObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDVulnerabilityObjects1Objects, 600, 60, "");
}{runtimeScene.getVariables().getFromIndex(3).setNumber(0);
}{for(var i = 0, len = gdjs.GameplayCode.GDLifeObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDLifeObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().getFromIndex(4), false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Vulnerability"), gdjs.GameplayCode.GDVulnerabilityObjects1);
{for(var i = 0, len = gdjs.GameplayCode.GDVulnerabilityObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDVulnerabilityObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
gdjs.GameplayCode.condition1IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "k");
}if ( gdjs.GameplayCode.condition0IsTrue_0.val ) {
{
{gdjs.GameplayCode.conditionTrue_1 = gdjs.GameplayCode.condition1IsTrue_0;
gdjs.GameplayCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10267444);
}
}}
if (gdjs.GameplayCode.condition1IsTrue_0.val) {
{gdjs.evtTools.common.toggleVariableBoolean(runtimeScene.getVariables().getFromIndex(9));
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().getFromIndex(9), true);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.GameplayCode.GDStatistics1Objects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameplayCode.mapOfGDgdjs_46GameplayCode_46GDStatistics1Objects1Objects, 600, 120, "");
}}

}


{


gdjs.GameplayCode.condition0IsTrue_0.val = false;
{
gdjs.GameplayCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().getFromIndex(9), false);
}if (gdjs.GameplayCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Statistics1"), gdjs.GameplayCode.GDStatistics1Objects1);
{for(var i = 0, len = gdjs.GameplayCode.GDStatistics1Objects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDStatistics1Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


};

gdjs.GameplayCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameplayCode.GDFood1Objects1.length = 0;
gdjs.GameplayCode.GDFood1Objects2.length = 0;
gdjs.GameplayCode.GDFood1Objects3.length = 0;
gdjs.GameplayCode.GDFood1_951Objects1.length = 0;
gdjs.GameplayCode.GDFood1_951Objects2.length = 0;
gdjs.GameplayCode.GDFood1_951Objects3.length = 0;
gdjs.GameplayCode.GDFood1_952Objects1.length = 0;
gdjs.GameplayCode.GDFood1_952Objects2.length = 0;
gdjs.GameplayCode.GDFood1_952Objects3.length = 0;
gdjs.GameplayCode.GDFood1_953Objects1.length = 0;
gdjs.GameplayCode.GDFood1_953Objects2.length = 0;
gdjs.GameplayCode.GDFood1_953Objects3.length = 0;
gdjs.GameplayCode.GDFood1_954Objects1.length = 0;
gdjs.GameplayCode.GDFood1_954Objects2.length = 0;
gdjs.GameplayCode.GDFood1_954Objects3.length = 0;
gdjs.GameplayCode.GDFood2Objects1.length = 0;
gdjs.GameplayCode.GDFood2Objects2.length = 0;
gdjs.GameplayCode.GDFood2Objects3.length = 0;
gdjs.GameplayCode.GDFood2_951Objects1.length = 0;
gdjs.GameplayCode.GDFood2_951Objects2.length = 0;
gdjs.GameplayCode.GDFood2_951Objects3.length = 0;
gdjs.GameplayCode.GDFood2_952Objects1.length = 0;
gdjs.GameplayCode.GDFood2_952Objects2.length = 0;
gdjs.GameplayCode.GDFood2_952Objects3.length = 0;
gdjs.GameplayCode.GDFood2_953Objects1.length = 0;
gdjs.GameplayCode.GDFood2_953Objects2.length = 0;
gdjs.GameplayCode.GDFood2_953Objects3.length = 0;
gdjs.GameplayCode.GDFood2_954Objects1.length = 0;
gdjs.GameplayCode.GDFood2_954Objects2.length = 0;
gdjs.GameplayCode.GDFood2_954Objects3.length = 0;
gdjs.GameplayCode.GDFood3Objects1.length = 0;
gdjs.GameplayCode.GDFood3Objects2.length = 0;
gdjs.GameplayCode.GDFood3Objects3.length = 0;
gdjs.GameplayCode.GDFood3_951Objects1.length = 0;
gdjs.GameplayCode.GDFood3_951Objects2.length = 0;
gdjs.GameplayCode.GDFood3_951Objects3.length = 0;
gdjs.GameplayCode.GDFood3_952Objects1.length = 0;
gdjs.GameplayCode.GDFood3_952Objects2.length = 0;
gdjs.GameplayCode.GDFood3_952Objects3.length = 0;
gdjs.GameplayCode.GDFood3_953Objects1.length = 0;
gdjs.GameplayCode.GDFood3_953Objects2.length = 0;
gdjs.GameplayCode.GDFood3_953Objects3.length = 0;
gdjs.GameplayCode.GDFood3_954Objects1.length = 0;
gdjs.GameplayCode.GDFood3_954Objects2.length = 0;
gdjs.GameplayCode.GDFood3_954Objects3.length = 0;
gdjs.GameplayCode.GDFood4Objects1.length = 0;
gdjs.GameplayCode.GDFood4Objects2.length = 0;
gdjs.GameplayCode.GDFood4Objects3.length = 0;
gdjs.GameplayCode.GDFood4_951Objects1.length = 0;
gdjs.GameplayCode.GDFood4_951Objects2.length = 0;
gdjs.GameplayCode.GDFood4_951Objects3.length = 0;
gdjs.GameplayCode.GDFood4_952Objects1.length = 0;
gdjs.GameplayCode.GDFood4_952Objects2.length = 0;
gdjs.GameplayCode.GDFood4_952Objects3.length = 0;
gdjs.GameplayCode.GDFood4_953Objects1.length = 0;
gdjs.GameplayCode.GDFood4_953Objects2.length = 0;
gdjs.GameplayCode.GDFood4_953Objects3.length = 0;
gdjs.GameplayCode.GDFood4_954Objects1.length = 0;
gdjs.GameplayCode.GDFood4_954Objects2.length = 0;
gdjs.GameplayCode.GDFood4_954Objects3.length = 0;
gdjs.GameplayCode.GDPizzaObjects1.length = 0;
gdjs.GameplayCode.GDPizzaObjects2.length = 0;
gdjs.GameplayCode.GDPizzaObjects3.length = 0;
gdjs.GameplayCode.GDKnifeObjects1.length = 0;
gdjs.GameplayCode.GDKnifeObjects2.length = 0;
gdjs.GameplayCode.GDKnifeObjects3.length = 0;
gdjs.GameplayCode.GDMasherObjects1.length = 0;
gdjs.GameplayCode.GDMasherObjects2.length = 0;
gdjs.GameplayCode.GDMasherObjects3.length = 0;
gdjs.GameplayCode.GDPeelerObjects1.length = 0;
gdjs.GameplayCode.GDPeelerObjects2.length = 0;
gdjs.GameplayCode.GDPeelerObjects3.length = 0;
gdjs.GameplayCode.GDScoreObjects1.length = 0;
gdjs.GameplayCode.GDScoreObjects2.length = 0;
gdjs.GameplayCode.GDScoreObjects3.length = 0;
gdjs.GameplayCode.GDOrderDisplayObjects1.length = 0;
gdjs.GameplayCode.GDOrderDisplayObjects2.length = 0;
gdjs.GameplayCode.GDOrderDisplayObjects3.length = 0;
gdjs.GameplayCode.GDLifeObjects1.length = 0;
gdjs.GameplayCode.GDLifeObjects2.length = 0;
gdjs.GameplayCode.GDLifeObjects3.length = 0;
gdjs.GameplayCode.GDNewObject2Objects1.length = 0;
gdjs.GameplayCode.GDNewObject2Objects2.length = 0;
gdjs.GameplayCode.GDNewObject2Objects3.length = 0;
gdjs.GameplayCode.GDNewObjectObjects1.length = 0;
gdjs.GameplayCode.GDNewObjectObjects2.length = 0;
gdjs.GameplayCode.GDNewObjectObjects3.length = 0;
gdjs.GameplayCode.GDProgressObjects1.length = 0;
gdjs.GameplayCode.GDProgressObjects2.length = 0;
gdjs.GameplayCode.GDProgressObjects3.length = 0;
gdjs.GameplayCode.GDStatistics1Objects1.length = 0;
gdjs.GameplayCode.GDStatistics1Objects2.length = 0;
gdjs.GameplayCode.GDStatistics1Objects3.length = 0;
gdjs.GameplayCode.GDVulnerabilityObjects1.length = 0;
gdjs.GameplayCode.GDVulnerabilityObjects2.length = 0;
gdjs.GameplayCode.GDVulnerabilityObjects3.length = 0;
gdjs.GameplayCode.GDGameOverMenuObjects1.length = 0;
gdjs.GameplayCode.GDGameOverMenuObjects2.length = 0;
gdjs.GameplayCode.GDGameOverMenuObjects3.length = 0;
gdjs.GameplayCode.GDGameOverTextObjects1.length = 0;
gdjs.GameplayCode.GDGameOverTextObjects2.length = 0;
gdjs.GameplayCode.GDGameOverTextObjects3.length = 0;
gdjs.GameplayCode.GDGameOverScoreObjects1.length = 0;
gdjs.GameplayCode.GDGameOverScoreObjects2.length = 0;
gdjs.GameplayCode.GDGameOverScoreObjects3.length = 0;
gdjs.GameplayCode.GDUsernameObjects1.length = 0;
gdjs.GameplayCode.GDUsernameObjects2.length = 0;
gdjs.GameplayCode.GDUsernameObjects3.length = 0;
gdjs.GameplayCode.GDUsernameHintObjects1.length = 0;
gdjs.GameplayCode.GDUsernameHintObjects2.length = 0;
gdjs.GameplayCode.GDUsernameHintObjects3.length = 0;
gdjs.GameplayCode.GDScoreSavedObjects1.length = 0;
gdjs.GameplayCode.GDScoreSavedObjects2.length = 0;
gdjs.GameplayCode.GDScoreSavedObjects3.length = 0;
gdjs.GameplayCode.GDSaveScoreObjects1.length = 0;
gdjs.GameplayCode.GDSaveScoreObjects2.length = 0;
gdjs.GameplayCode.GDSaveScoreObjects3.length = 0;
gdjs.GameplayCode.GDRestartButtonObjects1.length = 0;
gdjs.GameplayCode.GDRestartButtonObjects2.length = 0;
gdjs.GameplayCode.GDRestartButtonObjects3.length = 0;
gdjs.GameplayCode.GDMenuButtonObjects1.length = 0;
gdjs.GameplayCode.GDMenuButtonObjects2.length = 0;
gdjs.GameplayCode.GDMenuButtonObjects3.length = 0;
gdjs.GameplayCode.GDEscMenuTextObjects1.length = 0;
gdjs.GameplayCode.GDEscMenuTextObjects2.length = 0;
gdjs.GameplayCode.GDEscMenuTextObjects3.length = 0;
gdjs.GameplayCode.GDContinueButtonObjects1.length = 0;
gdjs.GameplayCode.GDContinueButtonObjects2.length = 0;
gdjs.GameplayCode.GDContinueButtonObjects3.length = 0;
gdjs.GameplayCode.GDEscMenuObjects1.length = 0;
gdjs.GameplayCode.GDEscMenuObjects2.length = 0;
gdjs.GameplayCode.GDEscMenuObjects3.length = 0;
gdjs.GameplayCode.GDFood8_954Objects1.length = 0;
gdjs.GameplayCode.GDFood8_954Objects2.length = 0;
gdjs.GameplayCode.GDFood8_954Objects3.length = 0;
gdjs.GameplayCode.GDFood8_953Objects1.length = 0;
gdjs.GameplayCode.GDFood8_953Objects2.length = 0;
gdjs.GameplayCode.GDFood8_953Objects3.length = 0;
gdjs.GameplayCode.GDFood8_952Objects1.length = 0;
gdjs.GameplayCode.GDFood8_952Objects2.length = 0;
gdjs.GameplayCode.GDFood8_952Objects3.length = 0;
gdjs.GameplayCode.GDFood8_951Objects1.length = 0;
gdjs.GameplayCode.GDFood8_951Objects2.length = 0;
gdjs.GameplayCode.GDFood8_951Objects3.length = 0;
gdjs.GameplayCode.GDFood8Objects1.length = 0;
gdjs.GameplayCode.GDFood8Objects2.length = 0;
gdjs.GameplayCode.GDFood8Objects3.length = 0;
gdjs.GameplayCode.GDFood7_954Objects1.length = 0;
gdjs.GameplayCode.GDFood7_954Objects2.length = 0;
gdjs.GameplayCode.GDFood7_954Objects3.length = 0;
gdjs.GameplayCode.GDFood7_953Objects1.length = 0;
gdjs.GameplayCode.GDFood7_953Objects2.length = 0;
gdjs.GameplayCode.GDFood7_953Objects3.length = 0;
gdjs.GameplayCode.GDFood7_952Objects1.length = 0;
gdjs.GameplayCode.GDFood7_952Objects2.length = 0;
gdjs.GameplayCode.GDFood7_952Objects3.length = 0;
gdjs.GameplayCode.GDFood7_951Objects1.length = 0;
gdjs.GameplayCode.GDFood7_951Objects2.length = 0;
gdjs.GameplayCode.GDFood7_951Objects3.length = 0;
gdjs.GameplayCode.GDFood7Objects1.length = 0;
gdjs.GameplayCode.GDFood7Objects2.length = 0;
gdjs.GameplayCode.GDFood7Objects3.length = 0;
gdjs.GameplayCode.GDFood6_954Objects1.length = 0;
gdjs.GameplayCode.GDFood6_954Objects2.length = 0;
gdjs.GameplayCode.GDFood6_954Objects3.length = 0;
gdjs.GameplayCode.GDFood6_953Objects1.length = 0;
gdjs.GameplayCode.GDFood6_953Objects2.length = 0;
gdjs.GameplayCode.GDFood6_953Objects3.length = 0;
gdjs.GameplayCode.GDFood6_952Objects1.length = 0;
gdjs.GameplayCode.GDFood6_952Objects2.length = 0;
gdjs.GameplayCode.GDFood6_952Objects3.length = 0;
gdjs.GameplayCode.GDFood6_951Objects1.length = 0;
gdjs.GameplayCode.GDFood6_951Objects2.length = 0;
gdjs.GameplayCode.GDFood6_951Objects3.length = 0;
gdjs.GameplayCode.GDFood6Objects1.length = 0;
gdjs.GameplayCode.GDFood6Objects2.length = 0;
gdjs.GameplayCode.GDFood6Objects3.length = 0;
gdjs.GameplayCode.GDFood5_954Objects1.length = 0;
gdjs.GameplayCode.GDFood5_954Objects2.length = 0;
gdjs.GameplayCode.GDFood5_954Objects3.length = 0;
gdjs.GameplayCode.GDFood5_953Objects1.length = 0;
gdjs.GameplayCode.GDFood5_953Objects2.length = 0;
gdjs.GameplayCode.GDFood5_953Objects3.length = 0;
gdjs.GameplayCode.GDFood5_952Objects1.length = 0;
gdjs.GameplayCode.GDFood5_952Objects2.length = 0;
gdjs.GameplayCode.GDFood5_952Objects3.length = 0;
gdjs.GameplayCode.GDFood5_951Objects1.length = 0;
gdjs.GameplayCode.GDFood5_951Objects2.length = 0;
gdjs.GameplayCode.GDFood5_951Objects3.length = 0;
gdjs.GameplayCode.GDFood5Objects1.length = 0;
gdjs.GameplayCode.GDFood5Objects2.length = 0;
gdjs.GameplayCode.GDFood5Objects3.length = 0;

gdjs.GameplayCode.eventsList23(runtimeScene);
return;

}

gdjs['GameplayCode'] = gdjs.GameplayCode;
